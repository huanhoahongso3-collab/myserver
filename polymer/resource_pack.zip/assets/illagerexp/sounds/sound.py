import os
import subprocess

files = [f for f in os.listdir('.') if f.endswith('.ogg')]

for file in files:
    temp_file = "temp_" + file
    
    try:
        # -ar 16000: Extreme downsampling (perfect for small SFX)
        # -ac 1: Force Mono (Required for 3D positional audio in MC)
        # -b:a 24k: Force a tiny 24kbps bitrate (Standard OGG is usually 128k+)
        # -application lowdelay: Optimizes for game triggers
        
        subprocess.run([
            'ffmpeg', '-i', file, 
            '-ar', '16000', 
            '-ac', '1', 
            '-map_metadata', '-1', 
            '-c:a', 'libvorbis', 
            '-b:a', '24k', 
            '-y', temp_file
        ], check=True, capture_output=True)
        
        # Replace original with the tiny version
        os.replace(temp_file, file)
        print(f"Max Compressed: {file} (16kHz @ 24kbps)")
        
    except subprocess.CalledProcessError as e:
        print(f"Error on {file}: {e.stderr.decode()}")
        if os.path.exists(temp_file):
            os.remove(temp_file)
