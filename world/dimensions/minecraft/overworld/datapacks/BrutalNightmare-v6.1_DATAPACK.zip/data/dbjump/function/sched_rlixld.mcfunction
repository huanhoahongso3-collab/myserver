scoreboard players set $9rnpp0Io uAZwdYKWv 0
execute if score $9rnpp0Io uAZwdYKWv matches 0 unless score $hidden.m0 st.activate matches 1 run function dbjump:nxf/5i5zf3d
execute if score $9rnpp0Io uAZwdYKWv matches 0 run function dbjump:nxf/w2mdmc13am
scoreboard players set $9rnpp0Io uAZwdYKWv 0