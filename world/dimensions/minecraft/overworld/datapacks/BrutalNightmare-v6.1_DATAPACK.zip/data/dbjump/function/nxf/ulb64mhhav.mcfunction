effect give @s minecraft:jump_boost 1 2 true
title @s actionbar ["",{"text":"Charged Jump","color":"green"}," : ",{"text":"II","color":"green"}]
execute as @s run scoreboard players set $LvgOa uAZwdYKWv 1