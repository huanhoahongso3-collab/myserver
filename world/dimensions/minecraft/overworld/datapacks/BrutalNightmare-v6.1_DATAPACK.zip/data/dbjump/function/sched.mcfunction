scoreboard players set $fokus.rn islib 0
function fokus:islib
execute if score $fokus.rn islib matches 1 run function dbjump:sched_rlixld