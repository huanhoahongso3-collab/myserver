tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $walljump st.success 1
scoreboard players set $walljump st.activate 0