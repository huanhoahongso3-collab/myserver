execute if score $db.fs db.menu.page matches 1..1 run scoreboard players add $db.fs db.menu.page 1
function dbjump:menu/main