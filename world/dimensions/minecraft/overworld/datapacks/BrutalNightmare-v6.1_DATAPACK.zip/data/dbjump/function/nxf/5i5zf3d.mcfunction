execute as @a[tag=!cfg.disjump] at @s run function dbjump:nxf/iwib
scoreboard players set $9rnpp0Io uAZwdYKWv 1