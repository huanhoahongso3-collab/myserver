particle dust{color:[1.0,1.0,1.0],scale:1.0} ~ ~0.5 ~ 0.3 0.3 0.3 0 30 normal
scoreboard players set $.xwB uAZwdYKWv 1