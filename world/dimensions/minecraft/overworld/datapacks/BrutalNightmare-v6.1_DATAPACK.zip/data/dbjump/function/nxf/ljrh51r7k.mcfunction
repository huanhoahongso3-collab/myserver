scoreboard players set $teSHGRw uAZwdYKWv 0
execute if score $teSHGRw uAZwdYKWv matches 0 run function dbjump:nxf/sd4a
execute if score $teSHGRw uAZwdYKWv matches 0 run function dbjump:nxf/8oj439jj
execute if score $teSHGRw uAZwdYKWv matches 0 run function dbjump:nxf/2wvpg3eax
execute if score $teSHGRw uAZwdYKWv matches 0 run function dbjump:nxf/10nd1iaculq
scoreboard players set $teSHGRw uAZwdYKWv 0