execute unless score $charjump st.activate matches 0 as @s[scores={dbj.sneak=1..}] run function dbjump:nxf/xlw7pg499uo
execute as @s[scores={dbj.sneak=0}] run scoreboard players set @s dbj.sneak_char 0
execute unless score $speeder st.activate matches 0 as @s[scores={dbj.sprint=1..}] run function dbjump:nxf/enkcmim
execute as @s[nbt={OnGround:0b},scores={dbj.sneak=1..}] unless score $doublejump st.activate matches 0 run function dbjump:nxf/3b200