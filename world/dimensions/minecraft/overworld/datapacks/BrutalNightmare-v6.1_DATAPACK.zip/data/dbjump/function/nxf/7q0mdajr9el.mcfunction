execute positioned ~ ~1 ~ run function dbjump:nxf/ljrh51r7k
execute at @s[tag=initdjump] run scoreboard players set $iKnd9DGLPw uAZwdYKWv 1