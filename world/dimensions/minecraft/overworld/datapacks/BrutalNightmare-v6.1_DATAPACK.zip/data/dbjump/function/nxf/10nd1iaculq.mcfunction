execute unless block ~ ~1 ~-1 air run function dbjump:nxf/mj7b
execute at @s[tag=initdjump] run scoreboard players set $teSHGRw uAZwdYKWv 1