scoreboard players set $walljump st.success 0
execute as @s if score $walljump st.success matches 0 if score $walljump st.activate matches 1 run function dbjump:menu/walljump_off
execute as @s if score $walljump st.success matches 0 unless score $walljump st.activate matches 1 run function dbjump:menu/walljump_on
scoreboard players set $walljump st.success 0
function dbjump:menu/main