tag @s add initdjump
tag @s remove candjump