tag @s remove djumped
function dbjump:nxf/mwo1