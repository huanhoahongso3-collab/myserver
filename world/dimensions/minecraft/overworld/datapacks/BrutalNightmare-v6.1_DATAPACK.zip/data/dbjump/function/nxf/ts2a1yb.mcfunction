effect give @s minecraft:jump_boost 1 3 true
title @s actionbar ["",{"text":"Charged Jump","color":"green"}," : ",{"text":"III","color":"dark_green"}]
execute as @s run scoreboard players set $LvgOa uAZwdYKWv 1