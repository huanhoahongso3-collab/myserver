tellraw @a "[MENU] Menu Activated"
scoreboard players set $charjump st.success 1
scoreboard players set $charjump st.activate 1