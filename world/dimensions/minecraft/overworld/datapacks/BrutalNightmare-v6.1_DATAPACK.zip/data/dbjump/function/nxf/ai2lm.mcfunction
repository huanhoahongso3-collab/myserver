scoreboard players set $pTQ2K uAZwdYKWv 0
execute if score $pTQ2K uAZwdYKWv matches 0 run function dbjump:nxf/ky608tyka
execute if score $pTQ2K uAZwdYKWv matches 0 run function dbjump:nxf/sujo9987li3
scoreboard players set $pTQ2K uAZwdYKWv 0