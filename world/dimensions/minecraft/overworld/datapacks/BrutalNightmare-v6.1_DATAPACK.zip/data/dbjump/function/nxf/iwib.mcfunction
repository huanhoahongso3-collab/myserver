execute as @s[nbt={OnGround:1b}] run function dbjump:nxf/eqstrfozn
execute as @s[tag=djumped_1,scores={dbj.jump=1..}] run function dbjump:nxf/hsapj
execute as @s[gamemode=survival] run function dbjump:nxf/eoq2
execute as @s[tag=initdjump,nbt={OnGround:0b}] run function dbjump:nxf/ivo5kuk6h1
execute as @s[tag=eff.slowf] at @s if block ~ ~-1 ~ barrier run function dbjump:nxf/lluxvuus06
execute as @e[type=minecraft:area_effect_cloud,tag=djump] at @s run function dbjump:nxf/ai2lm
execute as @s[scores={dbj.sneak=1..}] run scoreboard players set @s dbj.sneak 0
execute as @s[tag=!djumped_1,scores={dbj.jump=1..}] run scoreboard players set @s dbj.jump 0