scoreboard players set $.xwB uAZwdYKWv 0
execute if score $.xwB uAZwdYKWv matches 0 run function dbjump:nxf/_ignored_w731i7a71
execute if score $.xwB uAZwdYKWv matches 0 run function dbjump:nxf/_ignored_glyg6hemr
scoreboard players set $.xwB uAZwdYKWv 0
setblock ~ ~ ~ minecraft:barrier
scoreboard players set $pTQ2K uAZwdYKWv 1