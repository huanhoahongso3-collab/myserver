effect give @s slow_falling 1 0 true
execute if score MinecraftVersion VersionInfo matches 1..9 run function dbjump:nxf/glle
execute if score MinecraftVersion VersionInfo matches 10..14 run function dbjump:nxf/jcgv
execute if score MinecraftVersion VersionInfo matches 15.. run function dbjump:nxf/3vxh8
tag @s add eff.slowf