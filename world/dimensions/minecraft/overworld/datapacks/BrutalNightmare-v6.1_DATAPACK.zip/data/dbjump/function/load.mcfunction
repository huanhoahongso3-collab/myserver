scoreboard objectives add rl.basic dummy
scoreboard objectives add uAZwdYKWv dummy
scoreboard objectives add islib dummy
scoreboard objectives add ismodded dummy
scoreboard players set Modded ismodded 0
schedule function dbjump:load_welcome 5s
scoreboard players set $fokus.rn islib 0
function fokus:islib
execute unless score $fokus.rn islib matches 1 run tellraw @a {"text":"[DoubleJump] Please install FokusAPI for this pack","bold":true,"color":"green"}
execute unless score $fokus.rn islib matches 1 run schedule function dbjump:load 5s
execute if score $fokus.rn islib matches 1 run function dbjump:load_rlixld