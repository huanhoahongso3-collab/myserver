execute as @s[nbt={Age:20}] if block ~ ~ ~ barrier run setblock ~ ~ ~ air
scoreboard players set $pTQ2K uAZwdYKWv 1