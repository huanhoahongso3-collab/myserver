particle minecraft:dust 1.0 1.0 1.0 1.0 ~ ~0.5 ~ 0.3 0.3 0.3 0 30
scoreboard players set $.xwB uAZwdYKWv 1