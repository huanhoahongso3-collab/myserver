scoreboard players set $charjump st.success 0
execute as @s if score $charjump st.success matches 0 if score $charjump st.activate matches 1 run function dbjump:menu/charjump_off
execute as @s if score $charjump st.success matches 0 unless score $charjump st.activate matches 1 run function dbjump:menu/charjump_on
scoreboard players set $charjump st.success 0
function dbjump:menu/main