scoreboard players set $doublejump st.activate 1
scoreboard players set $charjump st.activate 1
scoreboard players set $walljump st.activate 1
scoreboard players set $dbj.bjump bonus_jump 2
scoreboard players set $speeder st.activate 1
scoreboard players set $db.fl st.activate 1