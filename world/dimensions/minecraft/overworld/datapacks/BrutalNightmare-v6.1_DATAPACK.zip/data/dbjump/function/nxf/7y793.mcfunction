scoreboard players set $iKnd9DGLPw uAZwdYKWv 0
execute if score $iKnd9DGLPw uAZwdYKWv matches 0 run function dbjump:nxf/7q0mdajr9el
execute if score $iKnd9DGLPw uAZwdYKWv matches 0 run function dbjump:nxf/ta5p
scoreboard players set $iKnd9DGLPw uAZwdYKWv 0