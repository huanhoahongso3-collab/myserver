effect give @s minecraft:speed 1 0 true
scoreboard players set @s dbj.sprint 0