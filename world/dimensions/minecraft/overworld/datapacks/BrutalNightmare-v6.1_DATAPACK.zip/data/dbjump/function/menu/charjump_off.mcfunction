tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $charjump st.success 1
scoreboard players set $charjump st.activate 0