tellraw @a "[MENU] Menu Activated"
scoreboard players set $walljump st.success 1
scoreboard players set $walljump st.activate 1