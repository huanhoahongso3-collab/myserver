execute as @s[tag=candjump] run function dbjump:nxf/mwo1
execute unless score $walljump st.activate matches 0 as @s[tag=!candjump,tag=djumped] run function dbjump:nxf/7y793