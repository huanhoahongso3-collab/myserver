tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $speeder st.success 1
scoreboard players set $speeder st.activate 0