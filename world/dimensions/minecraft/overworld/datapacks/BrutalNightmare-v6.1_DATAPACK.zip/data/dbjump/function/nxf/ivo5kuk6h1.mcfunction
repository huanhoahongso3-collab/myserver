execute as @s at @s if block ~ ~-1 ~ air run function dbjump:nxf/tcf5
tag @s remove initdjump