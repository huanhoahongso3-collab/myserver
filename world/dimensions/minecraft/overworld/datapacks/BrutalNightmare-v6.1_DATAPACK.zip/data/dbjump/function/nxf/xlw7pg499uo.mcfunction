scoreboard players set $LvgOa uAZwdYKWv 0
execute if score $LvgOa uAZwdYKWv matches 0 run function dbjump:nxf/rcqw0u4
execute if score $LvgOa uAZwdYKWv matches 0 run function dbjump:nxf/lhjan
execute if score $LvgOa uAZwdYKWv matches 0 run function dbjump:nxf/vehgdt
scoreboard players set $LvgOa uAZwdYKWv 0