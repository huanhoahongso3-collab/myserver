scoreboard objectives add reactify.isrunning dummy
scoreboard objectives add islib dummy
scoreboard objectives add ismodded dummy
scoreboard players set Modded ismodded 0
scoreboard objectives add rl.debug dummy
scoreboard objectives add bBHUN dummy
scoreboard objectives add VersionInfo dummy
scoreboard players add MinecraftVersion VersionInfo 0
function fokus:vd/cores/1.14