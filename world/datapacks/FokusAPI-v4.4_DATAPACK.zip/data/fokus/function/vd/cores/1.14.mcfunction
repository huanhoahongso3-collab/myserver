execute if entity @e[type=pillager]
scoreboard players set MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.15