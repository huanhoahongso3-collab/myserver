random value 0..1
# scoreboard players set MinecraftVersion VersionInfo 8
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.20.3