execute at @r run playsound block.note_block.bit ui @a
# scoreboard players set MinecraftVersion VersionInfo 15
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.21.7
