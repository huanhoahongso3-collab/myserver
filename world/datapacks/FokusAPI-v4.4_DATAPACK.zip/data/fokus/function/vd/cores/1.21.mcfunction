execute if entity @e[type=breeze]
# scoreboard players set MinecraftVersion VersionInfo 11
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.21.2