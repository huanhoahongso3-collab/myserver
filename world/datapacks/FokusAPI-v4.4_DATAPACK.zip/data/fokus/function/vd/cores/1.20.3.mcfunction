# gamerule projectilesCanBreakBlocks
# scoreboard players set MinecraftVersion VersionInfo 9
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.20.5