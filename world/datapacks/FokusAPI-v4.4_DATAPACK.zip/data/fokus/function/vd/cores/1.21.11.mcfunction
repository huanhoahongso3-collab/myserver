give @s netherite_horse_armor
# scoreboard players set MinecraftVersion VersionInfo 18
scoreboard players add MinecraftVersion VersionInfo 1