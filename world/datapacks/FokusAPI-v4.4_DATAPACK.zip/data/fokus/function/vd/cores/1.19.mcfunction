execute if entity @e[type=warden]
# scoreboard players set MinecraftVersion VersionInfo 6
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.20