spawnpoint @s ~ ~ ~ ~ ~
# scoreboard players set MinecraftVersion VersionInfo 17
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.21.11