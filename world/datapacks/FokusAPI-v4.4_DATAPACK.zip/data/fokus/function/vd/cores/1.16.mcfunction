execute if entity @e[type=piglin]
# scoreboard players set MinecraftVersion VersionInfo 3
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.17