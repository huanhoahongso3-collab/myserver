execute if entity @e[type=sniffer]
# scoreboard players set MinecraftVersion VersionInfo 7
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.20.2