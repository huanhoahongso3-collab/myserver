give @s music_disc_otherside
# scoreboard players set MinecraftVersion VersionInfo 5
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.19