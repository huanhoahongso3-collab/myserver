execute if entity @e[type=minecraft:creaking]
# scoreboard players set MinecraftVersion VersionInfo 14
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.21.6
