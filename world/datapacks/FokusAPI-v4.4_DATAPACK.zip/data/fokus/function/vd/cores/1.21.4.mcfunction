execute if block 0 0 0 open_eyeblossom
# scoreboard players set MinecraftVersion VersionInfo 13
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.21.5
