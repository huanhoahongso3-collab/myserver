give @s music_disc_lava_chicken
# scoreboard players set MinecraftVersion VersionInfo 16
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.21.9
