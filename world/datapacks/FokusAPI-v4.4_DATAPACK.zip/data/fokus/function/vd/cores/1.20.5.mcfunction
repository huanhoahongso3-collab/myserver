# gamerule spawnChunkRadius
# Force pass
# scoreboard players set MinecraftVersion VersionInfo 10
scoreboard players add MinecraftVersion VersionInfo 1
function fokus:vd/cores/1.21