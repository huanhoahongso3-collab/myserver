execute at @s positioned ^ ^ ^3 run function fokus:nxf/h2kehvsy
data modify entity @e[type=item,tag=dropped,limit=1] Item set from entity @s SelectedItem
data modify entity @e[type=item,tag=dropped,limit=1] Glowing set value true
scoreboard players set $ysg7waZ7s0I oE5VsWATY 0
execute if score $ysg7waZ7s0I oE5VsWATY matches 0 run function fokus:nxf/_ignored_bz824v3p9
execute if score $ysg7waZ7s0I oE5VsWATY matches 0 run function fokus:nxf/_ignored_5yzqma
scoreboard players set $ysg7waZ7s0I oE5VsWATY 0
tag @e[type=item,tag=dropped] remove dropped