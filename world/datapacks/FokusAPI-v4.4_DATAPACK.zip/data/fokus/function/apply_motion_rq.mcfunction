execute store result score @s dx1 run data get entity @s Pos[0] 1000
execute store result score @s dy1 run data get entity @s Pos[1] 1000
execute store result score @s dz1 run data get entity @s Pos[2] 1000
tp @s ^ ^ ^0.1
execute store result score @s dx2 run data get entity @s Pos[0] 1000
execute store result score @s dy2 run data get entity @s Pos[1] 1000
execute store result score @s dz2 run data get entity @s Pos[2] 1000
execute store result entity @s power[0] double 0.01 run scoreboard players operation @s dx2 -= @s dx1
execute store result entity @s power[1] double 0.01 run scoreboard players operation @s dy2 -= @s dy1
execute store result entity @s power[2] double 0.01 run scoreboard players operation @s dz2 -= @s dz1
tag @s add dadded