scoreboard objectives add fk.ttm dummy
function fokus:nxf/rmphof36