scoreboard objectives add fokus.isrunning dummy
scoreboard objectives add islib dummy
function fokus:tks_1sec
scoreboard objectives add ismodded dummy
scoreboard players set Modded ismodded 0
scoreboard objectives add rl.debug dummy
scoreboard objectives add oE5VsWATY dummy
scoreboard objectives add VersionInfo dummy
scoreboard players add MinecraftVersion VersionInfo 0
function fokus:vd/cores/1.14
# Load.mcfunction - This is exception
scoreboard objectives add fk.sneaking minecraft.custom:minecraft.sneak_time
scoreboard objectives add fokus.scores dummy
scoreboard objectives add fk.damage dummy
scoreboard objectives add rl.basic dummy
scoreboard objectives add fokus.rrv dummy
scoreboard objectives add fk.damaged minecraft.custom:minecraft.damage_taken
scoreboard objectives add dx1 dummy
scoreboard objectives add dy1 dummy
scoreboard objectives add dz1 dummy
scoreboard objectives add dx2 dummy
scoreboard objectives add dy2 dummy
scoreboard objectives add dz2 dummy
# Cloud's Minecraft RNG Algorithm
scoreboard objectives add clat.base minecraft.custom:minecraft.walk_one_cm
scoreboard objectives add clat.limit dummy
scoreboard objectives add clat.cache dummy
scoreboard objectives add clat.rslt dummy
# Lint V3 - Wait Function Support
scoreboard objectives add fk.ttm dummy
scoreboard objectives add fk.et.ptm dummy
scoreboard objectives add fk.tmp dummy
scoreboard players set $jqXxhf33fJ5 rl.basic 0
execute if score $jqXxhf33fJ5 rl.basic matches 0 run function fokus:nxf/rstqo
execute if score $jqXxhf33fJ5 rl.basic matches 0 run function fokus:nxf/cesvo9
scoreboard players set $jqXxhf33fJ5 rl.basic 0