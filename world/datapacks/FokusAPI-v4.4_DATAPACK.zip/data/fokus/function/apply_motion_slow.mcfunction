execute store result score @s dx1 run data get entity @s Pos[0] 300
execute store result score @s dy1 run data get entity @s Pos[1] 300
execute store result score @s dz1 run data get entity @s Pos[2] 300
tp @s ^ ^ ^0.1
execute store result score @s dx2 run data get entity @s Pos[0] 300
execute store result score @s dy2 run data get entity @s Pos[1] 300
execute store result score @s dz2 run data get entity @s Pos[2] 300
execute store result entity @s Motion[0] double 0.01 run scoreboard players operation @s dx2 -= @s dx1
execute store result entity @s Motion[1] double 0.01 run scoreboard players operation @s dy2 -= @s dy1
execute store result entity @s Motion[2] double 0.01 run scoreboard players operation @s dz2 -= @s dz1
tag @s add dadded
data modify entity @s NoGravity set value 0b