particle minecraft:cloud ~ ~ ~ 0 0 0 0.1 20
tp ~ ~-500 ~
kill @s