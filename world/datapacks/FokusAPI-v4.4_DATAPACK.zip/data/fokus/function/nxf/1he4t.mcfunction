kill @s
scoreboard players set $LdA0yTHfN oE5VsWATY 1