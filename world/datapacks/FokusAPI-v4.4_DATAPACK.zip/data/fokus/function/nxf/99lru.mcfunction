execute as @s if score $l.mc st.activate matches 0 unless predicate fokus:is_night run kill @e[tag=cspawn.rd,limit=1,sort=nearest]
execute as @s if score $l.mc st.activate matches 0 unless predicate fokus:canspawn run kill @e[tag=cspawn.rd,limit=1,sort=nearest]
execute as @s if entity @p[distance=..10] run kill @e[tag=cspawn.rd,limit=1,sort=nearest]