schedule function $this.file 1s
scoreboard players add $fk.ttm fk.ttm 1