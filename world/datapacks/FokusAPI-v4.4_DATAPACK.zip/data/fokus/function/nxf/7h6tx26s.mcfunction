scoreboard players set tz0uqfm fk.tmp 0
scoreboard players operation tz0uqfm fk.tmp += $fokusapi fk.ttm
scoreboard players operation tz0uqfm fk.tmp -= @s fk.et.ptm
scoreboard players operation @s fk.tmp = tz0uqfm fk.tmp