execute as @a[tag=fkapi.waittg] run function fokus:nxf/7h6tx26s
execute as @a[tag=fkapi.waittg] as @s[scores={fk.tmp=39..40}] at @s run function fokus:nxf/bzlyi