scoreboard players set @s fk.et.ptm 0
scoreboard players set @s fk.tmp 0
tag @s remove fkapi.waittg
say Come from 2s in the future