execute as @a[tag=fkapi.waittg] run function fokus:nxf/v1lm
execute as @a[tag=fkapi.waittg] as @s[scores={fk.tmp=29..30}] at @s run function fokus:nxf/n0j2e