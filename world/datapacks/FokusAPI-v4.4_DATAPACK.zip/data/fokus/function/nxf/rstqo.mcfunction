scoreboard objectives add fk.ptm minecraft.custom:minecraft.play_time
scoreboard players set $jqXxhf33fJ5 rl.basic 1