execute if score MinecraftVersion VersionInfo matches 3..9 run function fokus:nxf/wuhyhgvgnmn
execute if score MinecraftVersion VersionInfo matches 10.. run function fokus:nxf/zs711