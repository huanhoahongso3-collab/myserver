tag @s add fokus.fired
scoreboard players operation @s fk.damage = @p[tag=fk.target,limit=1] fk.damage
scoreboard players operation @s fk.damage *= @p[tag=fk.target,limit=1] fokus.scores
execute as @s store result entity @s damage double 0.01 run scoreboard players get @s fk.damage
tag @p[tag=fk.target,limit=1] remove fk.target
data modify entity @s Motion set value [0.0d,-0.7d,0.0d]