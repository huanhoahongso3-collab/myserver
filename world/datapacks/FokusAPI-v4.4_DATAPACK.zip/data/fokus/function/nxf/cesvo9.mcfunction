scoreboard objectives add fk.ptm minecraft.custom:minecraft.play_one_minute
scoreboard players set $jqXxhf33fJ5 rl.basic 1