scoreboard players set DP97Y8OX6d fk.tmp 0
scoreboard players operation DP97Y8OX6d fk.tmp += $fokusapi fk.ttm
scoreboard players operation DP97Y8OX6d fk.tmp -= @s fk.et.ptm
scoreboard players operation @s fk.tmp = DP97Y8OX6d fk.tmp