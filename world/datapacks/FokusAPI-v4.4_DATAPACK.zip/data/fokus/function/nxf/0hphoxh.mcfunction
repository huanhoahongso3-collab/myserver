execute as @a[tag=fkapi.waittg] run function fokus:nxf/3y2hbdnka
execute as @a[tag=fkapi.waittg] as @s[scores={fk.tmp=99..100}] at @s run function fokus:nxf/ra4bjc95sv