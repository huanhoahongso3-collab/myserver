spreadplayers ~ ~ 5 50 false @s
tp @e[tag=cspawn.rd,limit=1,sort=nearest] ~ ~ ~
execute as @s at @s unless entity @p[distance=..10] run function fokus:nxf/99lru
tag @s remove cspawn.rd
effect clear @s invisibility
kill @s