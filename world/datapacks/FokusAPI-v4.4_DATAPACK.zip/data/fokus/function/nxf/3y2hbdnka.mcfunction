scoreboard players set 5yGOsq2 fk.tmp 0
scoreboard players operation 5yGOsq2 fk.tmp += $fokusapi fk.ttm
scoreboard players operation 5yGOsq2 fk.tmp -= @s fk.et.ptm
scoreboard players operation @s fk.tmp = 5yGOsq2 fk.tmp