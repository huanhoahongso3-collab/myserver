tag @s add fokus.fired
execute as @s store result entity @s damage double 1.41 run scoreboard players get @p[tag=fk.target,limit=1] fk.damage
tag @p[tag=fk.target,limit=1] remove fk.target
data modify entity @s Motion set value [0.0d,-0.7d,0.0d]
tag @s remove fokus.dm