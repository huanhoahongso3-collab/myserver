execute as @s[scores={fokus.scores=1}] run summon zombie ~ ~ ~
execute as @s[scores={fokus.scores=2}] run summon skeleton ~ ~ ~
execute as @s[scores={fokus.scores=3}] run summon creeper ~ ~ ~
execute as @s[scores={fokus.scores=4}] run summon blaze ~ ~ ~
execute as @s[scores={fokus.scores=5}] run summon minecraft:wither_skeleton ~ ~ ~
execute as @s[scores={fokus.scores=6}] run summon minecraft:illusioner ~ ~ ~
execute as @s[scores={fokus.scores=7}] run summon minecraft:phantom ~ ~ ~ {Tags:["firept"]}
execute as @s[scores={fokus.scores=8}] run summon minecraft:creeper ~ ~ ~ {powered:1b}
scoreboard players set $LdA0yTHfN oE5VsWATY 1