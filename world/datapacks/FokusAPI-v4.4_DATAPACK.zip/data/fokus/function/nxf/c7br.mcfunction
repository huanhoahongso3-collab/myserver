scoreboard players set $LdA0yTHfN oE5VsWATY 0
execute if score $LdA0yTHfN oE5VsWATY matches 0 if score $l.mc st.activate matches 0 unless predicate fokus:is_night run function fokus:nxf/6hqpg4dvc8
execute if score $LdA0yTHfN oE5VsWATY matches 0 if score $l.mc st.activate matches 0 unless predicate fokus:canspawn run function fokus:nxf/1he4t
execute if score $LdA0yTHfN oE5VsWATY matches 0 run function fokus:nxf/fo3qe1xyj
scoreboard players set $LdA0yTHfN oE5VsWATY 0