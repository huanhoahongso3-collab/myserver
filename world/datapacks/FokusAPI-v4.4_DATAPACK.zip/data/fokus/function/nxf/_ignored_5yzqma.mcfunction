item replace entity @s weapon with air
scoreboard players set $ysg7waZ7s0I oE5VsWATY 1