scoreboard players operation @s fokus.scores = @p fokus.scores
spreadplayers ~5 ~5 10 140 false @s
execute as @s at @s unless entity @p[distance=..8] run function fokus:nxf/c7br
kill @s