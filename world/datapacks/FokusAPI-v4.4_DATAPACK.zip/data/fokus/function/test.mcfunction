tag @s add fkapi.waittg
scoreboard players operation @s fk.et.ptm = $fokusapi fk.ttm
schedule function fokus:nxf/dmtq 1.5s append