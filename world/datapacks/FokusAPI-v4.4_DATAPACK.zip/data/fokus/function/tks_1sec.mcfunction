schedule function fokus:tks_1sec 1t
scoreboard players add $fokusapi fk.ttm 1