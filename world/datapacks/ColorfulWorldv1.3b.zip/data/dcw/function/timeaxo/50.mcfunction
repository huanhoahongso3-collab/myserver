data modify entity @s Variant set value 0
scoreboard players set @s cw.axo.variant 0
tag @s remove cw.axo