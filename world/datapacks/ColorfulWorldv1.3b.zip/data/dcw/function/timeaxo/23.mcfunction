data modify entity @s Variant set value 3
scoreboard players set @s cw.axo.variant 3
tag @s remove cw.axo