data modify entity @s Variant set value 4
scoreboard players set @s cw.axo.variant 4
tag @s remove cw.axo