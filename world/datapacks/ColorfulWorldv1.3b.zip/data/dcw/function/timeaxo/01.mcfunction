data modify entity @s Variant set value 1
scoreboard players set @s cw.axo.variant 1
tag @s remove cw.axo