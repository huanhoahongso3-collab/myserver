data modify entity @s Variant set value 2
scoreboard players set @s cw.axo.variant 2
tag @s remove cw.axo