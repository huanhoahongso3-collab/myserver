data modify entity @s Variant set value 5
scoreboard players set @s cw.axo.variant 5
tag @s remove cw.axo