scoreboard objectives add cist.patcolour dummy
scoreboard objectives add cist.basecolour dummy
scoreboard objectives add cist.pattern dummy
scoreboard objectives add cist.shape dummy
scoreboard objectives add cist.result dummy
scoreboard objectives add cist.constant dummy
scoreboard players set 0 cist.constant 0
scoreboard players set 16777216 cist.constant 16777216
scoreboard players set 65536 cist.constant 65536
scoreboard players set 256 cist.constant 256

scoreboard objectives add cw.axo.variant dummy
scoreboard objectives add cw.cat.variant dummy
scoreboard objectives add cw.par.vari dummy
function dcw:time_axo
function dcw:time_cat
function dcw:time_fish
function dcw:time_parrot
function dcw:time_parrot
function dcw:catluck