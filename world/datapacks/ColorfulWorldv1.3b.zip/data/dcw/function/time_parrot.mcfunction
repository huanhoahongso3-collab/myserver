schedule function dcw:time_parrot 30t

tag @e[type=parrot,name=jeb_] add cw.par 
scoreboard players add @e[tag=cw.par] cw.par.vari 0

execute as @e[tag=cw.par,scores={cw.par.vari=0}] run function dcw:timeparrot/0_1

execute as @e[tag=cw.par,scores={cw.par.vari=1}] run function dcw:timeparrot/1_2

execute as @e[tag=cw.par,scores={cw.par.vari=2}] run function dcw:timeparrot/2_3

execute as @e[tag=cw.par,scores={cw.par.vari=3}] run function dcw:timeparrot/3_4

execute as @e[tag=cw.par,scores={cw.par.vari=4}] run function dcw:timeparrot/4_0

