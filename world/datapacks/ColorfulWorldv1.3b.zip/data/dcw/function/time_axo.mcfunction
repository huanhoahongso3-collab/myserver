schedule function dcw:time_axo 30t

tag @e[type=axolotl,name=jeb_] add cw.axo 
scoreboard players add @e[tag=cw.axo] cw.axo.variant 0

execute as @e[tag=cw.axo,scores={cw.axo.variant=0}] run function dcw:timeaxo/01

execute as @e[tag=cw.axo,scores={cw.axo.variant=1}] run function dcw:timeaxo/12

execute as @e[tag=cw.axo,scores={cw.axo.variant=2}] run function dcw:timeaxo/23

execute as @e[tag=cw.axo,scores={cw.axo.variant=3}] run function dcw:timeaxo/34

execute as @e[tag=cw.axo,scores={cw.axo.variant=4}] run function dcw:timeaxo/45

execute as @e[tag=cw.axo,scores={cw.axo.variant=5}] run function dcw:timeaxo/50
