data modify entity @s Variant set value 1
scoreboard players set @s cw.par.vari 1
tag @s remove cw.par