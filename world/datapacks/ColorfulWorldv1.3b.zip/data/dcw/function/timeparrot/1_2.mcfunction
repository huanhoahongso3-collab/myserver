data modify entity @s Variant set value 2
scoreboard players set @s cw.par.vari 2
tag @s remove cw.par