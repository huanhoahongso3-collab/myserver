data modify entity @s Variant set value 0
scoreboard players set @s cw.par.vari 0
tag @s remove cw.par