data modify entity @s Variant set value 3
scoreboard players set @s cw.par.vari 3
tag @s remove cw.par