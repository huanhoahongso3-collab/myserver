data modify entity @s Variant set value 4
scoreboard players set @s cw.par.vari 4
tag @s remove cw.par