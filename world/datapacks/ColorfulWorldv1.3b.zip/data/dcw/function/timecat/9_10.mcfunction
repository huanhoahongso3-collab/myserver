data modify entity @s variant set value "minecraft:jellie"
data modify entity @s CatType set value 10
scoreboard players set @s cw.cat.variant 10
tag @s remove cw.cat