data modify entity @s variant set value "minecraft:british_shorthair"
data modify entity @s CatType set value 5
scoreboard players set @s cw.cat.variant 5
tag @s remove cw.cat