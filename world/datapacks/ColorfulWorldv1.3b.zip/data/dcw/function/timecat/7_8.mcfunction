data modify entity @s variant set value "minecraft:ragdoll"
data modify entity @s CatType set value 8
scoreboard players set @s cw.cat.variant 8
tag @s remove cw.cat