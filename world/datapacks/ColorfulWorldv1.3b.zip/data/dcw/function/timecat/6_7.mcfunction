data modify entity @s variant set value "minecraft:persian"
data modify entity @s CatType set value 7
scoreboard players set @s cw.cat.variant 7
tag @s remove cw.cat