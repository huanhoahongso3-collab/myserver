data modify entity @s variant set value "minecraft:tabby"
data modify entity @s CatType set value 0
scoreboard players set @s cw.cat.variant 0
tag @s remove cw.cat