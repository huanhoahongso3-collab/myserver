data modify entity @s variant set value "minecraft:black"
data modify entity @s CatType set value 2
scoreboard players set @s cw.cat.variant 2
tag @s remove cw.cat