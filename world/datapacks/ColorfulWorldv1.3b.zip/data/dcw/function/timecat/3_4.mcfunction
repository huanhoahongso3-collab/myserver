data modify entity @s variant set value "minecraft:siamese"
data modify entity @s CatType set value 4
scoreboard players set @s cw.cat.variant 4
tag @s remove cw.cat