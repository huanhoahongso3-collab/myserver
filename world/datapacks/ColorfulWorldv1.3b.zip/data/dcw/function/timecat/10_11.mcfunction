data modify entity @s variant set value "minecraft:all_black"
data modify entity @s CatType set value 11
scoreboard players set @s cw.cat.variant 11
tag @s remove cw.cat