data modify entity @s variant set value "minecraft:red"
data modify entity @s CatType set value 3
scoreboard players set @s cw.cat.variant 3
tag @s remove cw.cat