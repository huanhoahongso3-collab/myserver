data modify entity @s variant set value "minecraft:calico"
data modify entity @s CatType set value 6
scoreboard players set @s cw.cat.variant 6
tag @s remove cw.cat