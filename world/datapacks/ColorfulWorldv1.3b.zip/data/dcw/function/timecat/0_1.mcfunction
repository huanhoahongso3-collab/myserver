data modify entity @s variant set value "minecraft:tabby"
data modify entity @s CatType set value 1
scoreboard players set @s cw.cat.variant 1
tag @s remove cw.cat