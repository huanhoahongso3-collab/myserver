data modify entity @s variant set value "minecraft:white"
data modify entity @s CatType set value 9
scoreboard players set @s cw.cat.variant 9
tag @s remove cw.cat