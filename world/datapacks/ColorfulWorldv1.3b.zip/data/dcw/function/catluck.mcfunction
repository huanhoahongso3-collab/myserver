schedule function dcw:catluck 8s
execute as @a[nbt={SelectedItem:{id:"minecraft:fishing_rod"}}] at @s if entity @e[type=cat,nbt={Sitting:1b},distance=..4] run effect give @s minecraft:luck 5 0 false

