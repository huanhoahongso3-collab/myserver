schedule function dcw:time_fish 15t

scoreboard players add @p cist.patcolour 1
scoreboard players set @p[scores={cist.patcolour=16..}] cist.patcolour 0
scoreboard players add @p[scores={cist.patcolour=0}] cist.basecolour 1
scoreboard players set @p[scores={cist.basecolour=16..}] cist.basecolour 0
scoreboard players add @p[scores={cist.patcolour=0,cist.basecolour=0}] cist.pattern 1
scoreboard players set @p[scores={cist.pattern=6..}] cist.pattern 0
scoreboard players add @p[scores={cist.patcolour=0,cist.basecolour=0,cist.pattern=0}] cist.shape 1
scoreboard players set @p[scores={cist.shape=2..}] cist.shape 0


scoreboard players operation variant cist.result = @p cist.patcolour
scoreboard players operation variant cist.result *= 16777216 cist.constant

scoreboard players operation variant1 cist.result = @p cist.basecolour
scoreboard players operation variant1 cist.result *= 65536 cist.constant

scoreboard players operation variant2 cist.result = @p cist.pattern
scoreboard players operation variant2 cist.result *= 256 cist.constant

scoreboard players operation variantg cist.result = 0 cist.constant
scoreboard players operation variantg cist.result += variant cist.result
scoreboard players operation variantg cist.result += variant1 cist.result
scoreboard players operation variantg cist.result += variant2 cist.result
scoreboard players operation variantg cist.result += @p cist.shape

execute as @e[type=tropical_fish,name=jeb_] store result entity @s Variant int 1 run scoreboard players get variantg cist.result