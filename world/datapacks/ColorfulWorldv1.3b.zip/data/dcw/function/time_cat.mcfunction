schedule function dcw:time_cat 30t

tag @e[type=cat,name=jeb_] add cw.cat
scoreboard players add @e[tag=cw.cat] cw.cat.variant 0

execute as @e[tag=cw.cat,scores={cw.cat.variant=0}] run function dcw:timecat/0_1
execute as @e[tag=cw.cat,scores={cw.cat.variant=1}] run function dcw:timecat/1_2
execute as @e[tag=cw.cat,scores={cw.cat.variant=2}] run function dcw:timecat/2_3
execute as @e[tag=cw.cat,scores={cw.cat.variant=3}] run function dcw:timecat/3_4
execute as @e[tag=cw.cat,scores={cw.cat.variant=4}] run function dcw:timecat/4_5
execute as @e[tag=cw.cat,scores={cw.cat.variant=5}] run function dcw:timecat/5_6
execute as @e[tag=cw.cat,scores={cw.cat.variant=6}] run function dcw:timecat/6_7
execute as @e[tag=cw.cat,scores={cw.cat.variant=7}] run function dcw:timecat/7_8
execute as @e[tag=cw.cat,scores={cw.cat.variant=8}] run function dcw:timecat/8_9
execute as @e[tag=cw.cat,scores={cw.cat.variant=9}] run function dcw:timecat/9_10
execute as @e[tag=cw.cat,scores={cw.cat.variant=10}] run function dcw:timecat/10_11
execute as @e[tag=cw.cat,scores={cw.cat.variant=11}] run function dcw:timecat/11_0
