schedule function cw:drowned/curse/_real_countdown 450s
execute as @a[scores={dr.dr_curse_cd=1..}] run scoreboard players remove @s dr.dr_curse_cd 1