tag @s add dr.curse
scoreboard players set @s dr.dr_curse 0
execute as @s at @s if block ~ ~ ~ water if block ~ ~-3 ~ water run function cw:nxf/curse_gjug
scoreboard players set $qizupSs HYKNM 0
execute if score $qizupSs HYKNM matches 0 run function cw:nxf/curse_imbpc
execute if score $qizupSs HYKNM matches 0 run function cw:nxf/curse_pi2a772b
scoreboard players set $qizupSs HYKNM 0