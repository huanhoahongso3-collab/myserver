scoreboard players set $qSybwrd HYKNM 0
execute if score $qSybwrd HYKNM matches 0 run function cw:nxf/cursing_y88su0o5lw
execute if score $qSybwrd HYKNM matches 0 run function cw:nxf/cursing_fazjbaxz1g0
scoreboard players set $qSybwrd HYKNM 0