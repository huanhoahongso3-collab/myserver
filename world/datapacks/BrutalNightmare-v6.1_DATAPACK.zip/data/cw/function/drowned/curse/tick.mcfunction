schedule function cw:drowned/curse/tick 1t
execute at @a[tag=dr.curse] as @e[type=armor_stand,limit=1,sort=nearest,tag=drowned_curse] at @s run function cw:nxf/tick_yz9bsgsx7yo
execute at @a as @e[type=armor_stand,limit=1,sort=nearest,tag=drowned_curse] at @s unless block ~ ~ ~ water run kill @s
execute as @a[scores={glob.shift=51..},tag=dr.curse] run scoreboard players set @s glob.shift 0
execute as @a[scores={glob.shift=1..},tag=!dr.curse] run scoreboard players set @s glob.shift 0