schedule function cw:screeper 3s
execute as @a[gamemode=survival] at @s if entity @e[type=creeper,distance=..3] run data modify entity @e[type=creeper,distance=..3,limit=1] ignited set value true