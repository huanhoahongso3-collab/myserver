schedule function cw:creeper/random_summon 60s
execute as @r[limit=7] at @s if predicate cw:r30 run function cw:nxf/random_summon_lbm4nj6o