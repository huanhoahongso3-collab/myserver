schedule function cw:creeper/boom_disguide 2s
execute as @e[type=husk,tag=creeper_psg] at @s as @e[tag=disguider,distance=..3] at @s if block ~ ~ ~ water run function cw:nxf/boom_disguide_rx2adh
execute as @e[type=husk,tag=creeper_psg] at @s if entity @p[distance=..4,gamemode=survival] positioned ~ ~ ~ run function cw:nxf/boom_disguide_628g0e