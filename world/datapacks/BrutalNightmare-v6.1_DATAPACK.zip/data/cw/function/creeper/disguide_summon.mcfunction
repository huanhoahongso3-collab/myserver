schedule function cw:creeper/disguide_summon 50s
execute as @r[limit=7] if predicate cw:r10 at @s run function cw:nxf/disguide_summon_n14e6