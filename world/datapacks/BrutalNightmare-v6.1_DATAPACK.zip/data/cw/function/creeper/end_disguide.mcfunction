schedule function cw:creeper/end_disguide 1t
execute as @e[type=husk,tag=creeper_psg] at @s unless entity @e[tag=disguider,distance=..3] run function cw:nxf/end_disguide_pio8kdc9zjv