schedule function cw:em/enderman 2s
execute as @r[scores={em.edm_curse=0,em.edm_curse_cd=0}] at @s if entity @e[type=enderman,distance=0..3,nbt=!{AngerTime:0}] if predicate cw:r30 run scoreboard players set @s em.edm_curse 30
execute as @a[scores={em.edm_curse=2..}] at @s run function cw:nxf/enderman_s2pv8ymee3b
execute as @a[scores={em.edm_curse=1}] at @s run function cw:nxf/enderman_0s5a3t93
execute as @e[type=enderman,tag=cursed_enderman] at @s run function cw:em/cursed_edm