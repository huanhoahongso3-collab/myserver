schedule function cw:em/invisible 8s
execute as @a at @s as @e[type=enderman,distance=..30,sort=random,limit=6,tag=!cw.given] at @s if predicate cw:r45 run function cw:nxf/invisible_ved37cjo8d1