schedule function cw:mwitch/drop 8s
execute as @e[tag=witcher_passenger,type=witch] at @s as @r[distance=0..5] if predicate cw:r30 run function fokus:drop