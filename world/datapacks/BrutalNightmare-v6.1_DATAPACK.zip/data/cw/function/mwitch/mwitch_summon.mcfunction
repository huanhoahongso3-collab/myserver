function cw:nxf/mwitch_summon_lk53s1azuo
kill @s