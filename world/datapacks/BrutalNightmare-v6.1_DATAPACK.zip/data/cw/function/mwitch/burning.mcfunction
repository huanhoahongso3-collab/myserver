schedule function cw:mwitch/burning 3s
execute as @e[tag=witcher_passenger,type=witch] at @s run effect give @a[distance=0..5] wither 4 0