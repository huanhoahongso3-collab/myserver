schedule function cw:mwitch/freeze 19s
execute as @e[tag=witcher_passenger,type=witch] at @s run execute as @a[distance=0..5] at @s run function cw:extend/_ignored_4
execute as @e[tag=witcher_passenger,type=witch] at @s run execute as @a[distance=0..5] at @s run function cw:mwitch/curse/curse_start