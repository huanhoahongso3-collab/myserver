tag @p[limit=1,sort=nearest,tag=fr.curse,scores={glob.shift2=50..}] remove dr.curse
kill @s