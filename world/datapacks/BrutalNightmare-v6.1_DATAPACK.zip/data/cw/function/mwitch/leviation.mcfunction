schedule function cw:mwitch/leviation 12s
execute as @e[tag=witcher_passenger,type=witch] at @s run execute as @a[distance=0..5] at @s run function cw:extend/_ignored_3
execute as @e[tag=witcher_passenger,type=witch] at @s run effect give @a[distance=0..5] levitation 4 1