schedule function cw:lightning/dlightning 7s
scoreboard players add @a l.ct 0
execute as @r[gamemode=survival,scores={l.hp=..7,l.ct=0},tag=!cw.target] at @s if predicate cw:r45 run function cw:nxf/dlightning_lt57g
execute as @a[scores={l.ct=1..}] at @s run function cw:nxf/dlightning_5yx1lvbz9v