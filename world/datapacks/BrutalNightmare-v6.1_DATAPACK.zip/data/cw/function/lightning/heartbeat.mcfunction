schedule function cw:lightning/heartbeat 2s
execute as @a[tag=cw.target,gamemode=survival] at @s run function cw:nxf/heartbeat_b02an6