schedule function cw:jockey/spawn 200s
execute as @r[limit=10] at @s if predicate cw:r20 run function cw:nxf/spawn_ju6rvft7