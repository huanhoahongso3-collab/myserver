schedule function cw:jockey/jockey_speed 1s
execute as @e[tag=speeder] run function cw:nxf/jockey_speed_h4e42