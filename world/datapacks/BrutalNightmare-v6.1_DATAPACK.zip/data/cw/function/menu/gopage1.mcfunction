scoreboard players set $cw.fs cw.menu.page 1
function cw:menu/main