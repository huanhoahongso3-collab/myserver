tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $gh.smul st.success 1
scoreboard players set $gh.smul st.activate 0
schedule clear cw:ghasts/gh_gatling
schedule clear cw:ghasts/shooter