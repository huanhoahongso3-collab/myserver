scoreboard players set $dc.nervous st.success 0
execute as @s if score $dc.nervous st.success matches 0 if score $dc.nervous st.activate matches 1 run function cw:menu/dcnervous_off
execute as @s if score $dc.nervous st.success matches 0 unless score $dc.nervous st.activate matches 1 run function cw:menu/dcnervous_on
scoreboard players set $dc.nervous st.success 0
function cw:menu/main