tellraw @a "[MENU] Menu Activated"
scoreboard players set $dr.curse st.success 1
scoreboard players set $dr.curse st.activate 1
function cw:drowned/curse/tick
function cw:drowned/curse/tick
function cw:drowned/curse/_real_countdown
function cw:drowned/curse/_real_on
function cw:drowned/curse/_real_start