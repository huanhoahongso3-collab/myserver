tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $bl.caskill st.success 1
scoreboard players set $bl.caskill st.activate 0
schedule clear cw:blaze/doubler