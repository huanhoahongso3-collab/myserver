tellraw @a "[MENU] Menu Activated"
scoreboard players set $gh.smul st.success 1
scoreboard players set $gh.smul st.activate 1
function cw:ghasts/gh_gatling
function cw:ghasts/shooter