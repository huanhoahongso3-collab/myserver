scoreboard players set $cr.smai st.success 0
execute as @s if score $cr.smai st.success matches 0 if score $cr.smai st.activate matches 1 run function cw:menu/crsmai_off
execute as @s if score $cr.smai st.success matches 0 unless score $cr.smai st.activate matches 1 run function cw:menu/crsmai_on
scoreboard players set $cr.smai st.success 0
function cw:menu/main