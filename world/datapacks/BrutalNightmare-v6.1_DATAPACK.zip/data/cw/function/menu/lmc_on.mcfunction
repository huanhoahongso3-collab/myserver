tellraw @a "[MENU] Menu Activated"
scoreboard players set $l.mc st.success 1
scoreboard players set $l.mc st.activate 1