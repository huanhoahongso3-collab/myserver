scoreboard players set $dr.caskill st.success 0
execute as @s if score $dr.caskill st.success matches 0 if score $dr.caskill st.activate matches 1 run function cw:menu/drcaskill_off
execute as @s if score $dr.caskill st.success matches 0 unless score $dr.caskill st.activate matches 1 run function cw:menu/drcaskill_on
scoreboard players set $dr.caskill st.success 0
function cw:menu/main