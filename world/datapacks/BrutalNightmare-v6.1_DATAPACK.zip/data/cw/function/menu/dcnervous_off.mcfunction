tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $dc.nervous st.success 1
scoreboard players set $dc.nervous st.activate 0
schedule clear cw:hardattrb/dark_curse