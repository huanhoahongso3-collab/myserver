tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $l.mc st.success 1
scoreboard players set $l.mc st.activate 0