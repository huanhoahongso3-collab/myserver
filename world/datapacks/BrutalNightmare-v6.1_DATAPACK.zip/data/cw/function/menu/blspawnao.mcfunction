scoreboard players set $bl.spawnao st.success 0
execute as @s if score $bl.spawnao st.success matches 0 if score $bl.spawnao st.activate matches 1 run function cw:menu/blspawnao_off
execute as @s if score $bl.spawnao st.success matches 0 unless score $bl.spawnao st.activate matches 1 run function cw:menu/blspawnao_on
scoreboard players set $bl.spawnao st.success 0
function cw:menu/main