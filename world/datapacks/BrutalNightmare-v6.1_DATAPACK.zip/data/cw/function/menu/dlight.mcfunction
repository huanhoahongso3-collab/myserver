scoreboard players set $d.light st.success 0
execute as @s if score $d.light st.success matches 0 if score $d.light st.activate matches 1 run function cw:menu/dlight_off
execute as @s if score $d.light st.success matches 0 unless score $d.light st.activate matches 1 run function cw:menu/dlight_on
scoreboard players set $d.light st.success 0
function cw:menu/main