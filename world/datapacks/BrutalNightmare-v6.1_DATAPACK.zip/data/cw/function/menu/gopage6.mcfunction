scoreboard players set $cw.fs cw.menu.page 6
function cw:menu/main