scoreboard players set $cw.fs cw.menu.page 7
function cw:menu/main