tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $em.curse st.success 1
scoreboard players set $em.curse st.activate 0
schedule clear cw:em/em
schedule clear cw:em/em_cs
schedule clear cw:em/enderman