scoreboard players set $cw.fs cw.menu.page 2
function cw:menu/main