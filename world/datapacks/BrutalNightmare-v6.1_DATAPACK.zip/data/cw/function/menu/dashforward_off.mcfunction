tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $dashforward st.success 1
scoreboard players set $dashforward st.activate 0
schedule clear cw:hardattrb/dashforward