tellraw @a "[MENU] Menu Activated"
scoreboard players set $dc.nervous st.success 1
scoreboard players set $dc.nervous st.activate 1
function cw:hardattrb/dark_curse