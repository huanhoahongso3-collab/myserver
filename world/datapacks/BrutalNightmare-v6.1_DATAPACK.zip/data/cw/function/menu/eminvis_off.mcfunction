tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $em.invis st.success 1
scoreboard players set $em.invis st.activate 0
schedule clear cw:em/invisible