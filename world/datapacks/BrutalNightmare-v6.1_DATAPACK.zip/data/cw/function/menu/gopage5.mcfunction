scoreboard players set $cw.fs cw.menu.page 5
function cw:menu/main