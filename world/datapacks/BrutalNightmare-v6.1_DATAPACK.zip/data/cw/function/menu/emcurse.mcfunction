scoreboard players set $em.curse st.success 0
execute as @s if score $em.curse st.success matches 0 if score $em.curse st.activate matches 1 run function cw:menu/emcurse_off
execute as @s if score $em.curse st.success matches 0 unless score $em.curse st.activate matches 1 run function cw:menu/emcurse_on
scoreboard players set $em.curse st.success 0
function cw:menu/main