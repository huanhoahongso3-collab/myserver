tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $bn.wm st.success 1
scoreboard players set $bn.wm st.activate 0