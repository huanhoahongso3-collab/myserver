scoreboard players set $cw.fs cw.menu.page 10
function cw:menu/main