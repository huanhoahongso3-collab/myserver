tellraw @a "[MENU] Menu Activated"
scoreboard players set $em.invis st.success 1
scoreboard players set $em.invis st.activate 1
function cw:em/invisible