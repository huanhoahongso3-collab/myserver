tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $bl.spl st.success 1
scoreboard players set $bl.spl st.activate 0