scoreboard players set $bl.usecurse st.success 0
execute as @s if score $bl.usecurse st.success matches 0 if score $bl.usecurse st.activate matches 1 run function cw:menu/blusecurse_off
execute as @s if score $bl.usecurse st.success matches 0 unless score $bl.usecurse st.activate matches 1 run function cw:menu/blusecurse_on
scoreboard players set $bl.usecurse st.success 0
function cw:menu/main