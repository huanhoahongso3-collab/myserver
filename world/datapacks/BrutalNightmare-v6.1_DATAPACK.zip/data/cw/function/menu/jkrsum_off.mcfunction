tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $jk.rsum st.success 1
scoreboard players set $jk.rsum st.activate 0
schedule clear cw:jockey/spawn
schedule clear cw:jockey/jockey_speed