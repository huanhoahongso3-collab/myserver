scoreboard players set $bn.wm st.success 0
execute as @s if score $bn.wm st.success matches 0 if score $bn.wm st.activate matches 1 run function cw:menu/bnwm_off
execute as @s if score $bn.wm st.success matches 0 unless score $bn.wm st.activate matches 1 run function cw:menu/bnwm_on
scoreboard players set $bn.wm st.success 0
function cw:menu/main