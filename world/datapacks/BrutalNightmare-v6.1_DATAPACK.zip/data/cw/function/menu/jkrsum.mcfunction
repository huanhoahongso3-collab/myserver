scoreboard players set $jk.rsum st.success 0
execute as @s if score $jk.rsum st.success matches 0 if score $jk.rsum st.activate matches 1 run function cw:menu/jkrsum_off
execute as @s if score $jk.rsum st.success matches 0 unless score $jk.rsum st.activate matches 1 run function cw:menu/jkrsum_on
scoreboard players set $jk.rsum st.success 0
function cw:menu/main