scoreboard players set $em.caskill st.success 0
execute as @s if score $em.caskill st.success matches 0 if score $em.caskill st.activate matches 1 run function cw:menu/emcaskill_off
execute as @s if score $em.caskill st.success matches 0 unless score $em.caskill st.activate matches 1 run function cw:menu/emcaskill_on
scoreboard players set $em.caskill st.success 0
function cw:menu/main