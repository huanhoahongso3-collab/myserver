scoreboard players set $bl.spl st.success 0
execute as @s if score $bl.spl st.success matches 0 if score $bl.spl st.activate matches 1 run function cw:menu/blspl_off
execute as @s if score $bl.spl st.success matches 0 unless score $bl.spl st.activate matches 1 run function cw:menu/blspl_on
scoreboard players set $bl.spl st.success 0
function cw:menu/main