tellraw @a "[MENU] Menu Activated"
scoreboard players set $cr.ssnow st.success 1
scoreboard players set $cr.ssnow st.activate 1
function cw:creeper/creeper_shoot_snowball