tellraw @a "[MENU] Menu Activated"
scoreboard players set $mob.inv st.success 1
scoreboard players set $mob.inv st.activate 1
function cw:invisiblem