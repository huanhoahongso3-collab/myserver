tellraw @a "[MENU] Menu Activated"
scoreboard players set $bn.wm st.success 1
scoreboard players set $bn.wm st.activate 1