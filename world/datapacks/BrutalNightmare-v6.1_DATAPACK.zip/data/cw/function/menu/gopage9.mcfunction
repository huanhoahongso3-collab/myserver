scoreboard players set $cw.fs cw.menu.page 9
function cw:menu/main