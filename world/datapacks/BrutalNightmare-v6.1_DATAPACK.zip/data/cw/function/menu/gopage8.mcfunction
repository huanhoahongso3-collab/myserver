scoreboard players set $cw.fs cw.menu.page 8
function cw:menu/main