tellraw @a "[MENU] Menu Activated"
scoreboard players set $d.light st.success 1
scoreboard players set $d.light st.activate 1
function cw:lightning/dlightning
function cw:lightning/heartbeat