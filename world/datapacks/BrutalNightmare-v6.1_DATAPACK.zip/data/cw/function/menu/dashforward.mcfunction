scoreboard players set $dashforward st.success 0
execute as @s if score $dashforward st.success matches 0 if score $dashforward st.activate matches 1 run function cw:menu/dashforward_off
execute as @s if score $dashforward st.success matches 0 unless score $dashforward st.activate matches 1 run function cw:menu/dashforward_on
scoreboard players set $dashforward st.success 0
function cw:menu/main