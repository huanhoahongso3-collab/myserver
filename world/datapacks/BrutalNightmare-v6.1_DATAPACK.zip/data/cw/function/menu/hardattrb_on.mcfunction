tellraw @a "[MENU] Menu Activated"
scoreboard players set $hardattrb st.success 1
scoreboard players set $hardattrb st.activate 1
function cw:hardattrb/hardattrb