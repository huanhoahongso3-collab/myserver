scoreboard players set $ilu.rsum st.success 0
execute as @s if score $ilu.rsum st.success matches 0 if score $ilu.rsum st.activate matches 1 run function cw:menu/ilursum_off
execute as @s if score $ilu.rsum st.success matches 0 unless score $ilu.rsum st.activate matches 1 run function cw:menu/ilursum_on
scoreboard players set $ilu.rsum st.success 0
function cw:menu/main