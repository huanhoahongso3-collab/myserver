tellraw @a "[MENU] Menu Activated"
scoreboard players set $em.curse st.success 1
scoreboard players set $em.curse st.activate 1
function cw:em/em
function cw:em/em_cs
function cw:em/enderman