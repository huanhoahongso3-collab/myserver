tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $bl.usecurse st.success 1
scoreboard players set $bl.usecurse st.activate 0
schedule clear cw:blaze/use_curse