tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $d.light st.success 1
scoreboard players set $d.light st.activate 0
schedule clear cw:lightning/dlightning
schedule clear cw:lightning/heartbeat