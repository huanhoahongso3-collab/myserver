scoreboard players set $dr.curse st.success 0
execute as @s if score $dr.curse st.success matches 0 if score $dr.curse st.activate matches 1 run function cw:menu/drcurse_off
execute as @s if score $dr.curse st.success matches 0 unless score $dr.curse st.activate matches 1 run function cw:menu/drcurse_on
scoreboard players set $dr.curse st.success 0
function cw:menu/main