tellraw @a "[MENU] Menu Activated"
scoreboard players set $sk.smai st.success 1
scoreboard players set $sk.smai st.activate 1
function cw:skeleton/swapper