tellraw @a "[MENU] Menu Activated"
scoreboard players set $zb.dbs st.success 1
scoreboard players set $zb.dbs st.activate 1
function cw:zombie/dbs