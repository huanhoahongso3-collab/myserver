tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $zb.newabi st.success 1
scoreboard players set $zb.newabi st.activate 0
schedule clear cw:zombie/ability
schedule clear cw:husk/ability