tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $sp.invis st.success 1
scoreboard players set $sp.invis st.activate 0
schedule clear cw:spider/invisible