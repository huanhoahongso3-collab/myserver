scoreboard players set $slime.sb st.success 0
execute as @s if score $slime.sb st.success matches 0 if score $slime.sb st.activate matches 1 run function cw:menu/slimesb_off
execute as @s if score $slime.sb st.success matches 0 unless score $slime.sb st.activate matches 1 run function cw:menu/slimesb_on
scoreboard players set $slime.sb st.success 0
function cw:menu/main