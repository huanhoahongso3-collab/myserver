tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $ptom.invis st.success 1
scoreboard players set $ptom.invis st.activate 0
schedule clear cw:phantom/invisible