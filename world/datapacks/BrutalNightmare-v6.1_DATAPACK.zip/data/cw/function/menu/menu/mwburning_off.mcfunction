tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $mw.burning st.success 1
scoreboard players set $mw.burning st.activate 0
schedule clear cw:mwitch/burning