tellraw @a "[MENU] Menu Activated"
scoreboard players set $zb.noburn st.success 1
scoreboard players set $zb.noburn st.activate 1
function cw:zombie/ssmob