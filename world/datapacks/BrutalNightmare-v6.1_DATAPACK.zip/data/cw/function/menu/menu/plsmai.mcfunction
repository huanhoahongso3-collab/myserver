scoreboard players set $pl.smai st.success 0
execute as @s if score $pl.smai st.success matches 0 if score $pl.smai st.activate matches 1 run function cw:menu/plsmai_off
execute as @s if score $pl.smai st.success matches 0 unless score $pl.smai st.activate matches 1 run function cw:menu/plsmai_on
scoreboard players set $pl.smai st.success 0
function cw:menu/main