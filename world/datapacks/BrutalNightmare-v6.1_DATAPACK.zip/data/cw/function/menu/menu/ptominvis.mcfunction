scoreboard players set $ptom.invis st.success 0
execute as @s if score $ptom.invis st.success matches 0 if score $ptom.invis st.activate matches 1 run function cw:menu/ptominvis_off
execute as @s if score $ptom.invis st.success matches 0 unless score $ptom.invis st.activate matches 1 run function cw:menu/ptominvis_on
scoreboard players set $ptom.invis st.success 0
function cw:menu/main