tellraw @a "[MENU] Menu Activated"
scoreboard players set $vd.statue st.success 1
scoreboard players set $vd.statue st.activate 1
function cw:vindicator/nvin_kars
function cw:vindicator/nvin
function cw:vindicator/nvin_summon