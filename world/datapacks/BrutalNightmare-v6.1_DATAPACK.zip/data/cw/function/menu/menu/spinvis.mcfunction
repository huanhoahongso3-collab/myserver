scoreboard players set $sp.invis st.success 0
execute as @s if score $sp.invis st.success matches 0 if score $sp.invis st.activate matches 1 run function cw:menu/spinvis_off
execute as @s if score $sp.invis st.success matches 0 unless score $sp.invis st.activate matches 1 run function cw:menu/spinvis_on
scoreboard players set $sp.invis st.success 0
function cw:menu/main