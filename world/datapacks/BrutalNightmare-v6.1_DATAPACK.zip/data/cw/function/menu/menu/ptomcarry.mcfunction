scoreboard players set $ptom.carry st.success 0
execute as @s if score $ptom.carry st.success matches 0 if score $ptom.carry st.activate matches 1 run function cw:menu/ptomcarry_off
execute as @s if score $ptom.carry st.success matches 0 unless score $ptom.carry st.activate matches 1 run function cw:menu/ptomcarry_on
scoreboard players set $ptom.carry st.success 0
function cw:menu/main