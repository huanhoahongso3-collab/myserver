tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $sfish.ife st.success 1
scoreboard players set $sfish.ife st.activate 0
schedule clear cw:silverfish/infection
schedule clear cw:silverfish/infect_loop