scoreboard players set $m.gear st.success 0
execute as @s if score $m.gear st.success matches 0 if score $m.gear st.activate matches 1 run function cw:menu/mgear_off
execute as @s if score $m.gear st.success matches 0 unless score $m.gear st.activate matches 1 run function cw:menu/mgear_on
scoreboard players set $m.gear st.success 0
function cw:menu/main