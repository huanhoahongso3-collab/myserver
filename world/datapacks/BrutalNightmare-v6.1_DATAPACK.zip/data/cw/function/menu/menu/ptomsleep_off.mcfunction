tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $ptom.sleep st.success 1
scoreboard players set $ptom.sleep st.activate 0
schedule clear cw:phantom/sleep_nm
schedule clear cw:phantom/firept