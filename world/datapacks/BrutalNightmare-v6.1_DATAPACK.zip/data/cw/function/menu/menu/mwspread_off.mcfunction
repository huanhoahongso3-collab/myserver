tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $mw.spread st.success 1
scoreboard players set $mw.spread st.activate 0
schedule clear cw:mwitch/spread