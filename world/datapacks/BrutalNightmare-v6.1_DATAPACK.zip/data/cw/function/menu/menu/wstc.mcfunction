scoreboard players set $ws.tc st.success 0
execute as @s if score $ws.tc st.success matches 0 if score $ws.tc st.activate matches 1 run function cw:menu/wstc_off
execute as @s if score $ws.tc st.success matches 0 unless score $ws.tc st.activate matches 1 run function cw:menu/wstc_on
scoreboard players set $ws.tc st.success 0
function cw:menu/main