tellraw @a "[MENU] Menu Activated"
scoreboard players set $sk.noburn st.success 1
scoreboard players set $sk.noburn st.activate 1
function cw:skeleton/ssmob