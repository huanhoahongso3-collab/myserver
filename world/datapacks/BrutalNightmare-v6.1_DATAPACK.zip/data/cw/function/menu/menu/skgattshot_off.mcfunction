tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $sk.gattshot st.success 1
scoreboard players set $sk.gattshot st.activate 0
schedule clear cw:skeleton/ske_gatling
schedule clear cw:skeleton/shooter