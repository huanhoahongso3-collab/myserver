tellraw @a "[MENU] Menu Activated"
scoreboard players set $ws.tc st.success 1
scoreboard players set $ws.tc st.activate 1
function cw:witherskeleton/the_challenger