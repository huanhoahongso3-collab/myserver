tellraw @a "[MENU] Menu Activated"
scoreboard players set $zb.allbreaker st.success 1
scoreboard players set $zb.allbreaker st.activate 1