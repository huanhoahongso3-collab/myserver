tellraw @a "[MENU] Menu Activated"
scoreboard players set $m.gear st.success 1
scoreboard players set $m.gear st.activate 1
function cw:geardrop