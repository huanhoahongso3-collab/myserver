scoreboard players set $sfish.ife st.success 0
execute as @s if score $sfish.ife st.success matches 0 if score $sfish.ife st.activate matches 1 run function cw:menu/sfishife_off
execute as @s if score $sfish.ife st.success matches 0 unless score $sfish.ife st.activate matches 1 run function cw:menu/sfishife_on
scoreboard players set $sfish.ife st.success 0
function cw:menu/main