scoreboard players set $sk.caskill st.success 0
execute as @s if score $sk.caskill st.success matches 0 if score $sk.caskill st.activate matches 1 run function cw:menu/skcaskill_off
execute as @s if score $sk.caskill st.success matches 0 unless score $sk.caskill st.activate matches 1 run function cw:menu/skcaskill_on
scoreboard players set $sk.caskill st.success 0
function cw:menu/main