tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $mw.enable st.success 1
scoreboard players set $mw.enable st.activate 0
schedule clear cw:mwitch/mwitch