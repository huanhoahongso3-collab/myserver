tellraw @a "[MENU] Menu Activated"
scoreboard players set $ptom.sleep st.success 1
scoreboard players set $ptom.sleep st.activate 1
function cw:phantom/sleep_nm
function cw:phantom/firept