scoreboard players set $psive.fb st.success 0
execute as @s if score $psive.fb st.success matches 0 if score $psive.fb st.activate matches 1 run function cw:menu/psivefb_off
execute as @s if score $psive.fb st.success matches 0 unless score $psive.fb st.activate matches 1 run function cw:menu/psivefb_on
scoreboard players set $psive.fb st.success 0
function cw:menu/main