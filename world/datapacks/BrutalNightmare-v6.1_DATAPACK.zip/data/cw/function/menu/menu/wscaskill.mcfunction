scoreboard players set $ws.caskill st.success 0
execute as @s if score $ws.caskill st.success matches 0 if score $ws.caskill st.activate matches 1 run function cw:menu/wscaskill_off
execute as @s if score $ws.caskill st.success matches 0 unless score $ws.caskill st.activate matches 1 run function cw:menu/wscaskill_on
scoreboard players set $ws.caskill st.success 0
function cw:menu/main