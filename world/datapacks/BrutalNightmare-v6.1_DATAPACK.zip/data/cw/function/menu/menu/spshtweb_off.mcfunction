tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $sp.shtweb st.success 1
scoreboard players set $sp.shtweb st.activate 0
schedule clear cw:spider/spider