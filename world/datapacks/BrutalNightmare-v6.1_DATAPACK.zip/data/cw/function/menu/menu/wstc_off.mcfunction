tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $ws.tc st.success 1
scoreboard players set $ws.tc st.activate 0
schedule clear cw:witherskeleton/the_challenger