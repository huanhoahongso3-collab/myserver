tellraw @a "[MENU] Menu Activated"
scoreboard players set $mw.freeze st.success 1
scoreboard players set $mw.freeze st.activate 1
function cw:mwitch/freeze
function cw:mwitch/curse/tick