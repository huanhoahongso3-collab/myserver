tellraw @a "[MENU] Menu Activated"
scoreboard players set $sp.shtweb st.success 1
scoreboard players set $sp.shtweb st.activate 1
function cw:spider/spider