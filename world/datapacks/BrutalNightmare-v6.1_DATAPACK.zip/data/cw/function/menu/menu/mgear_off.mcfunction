tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $m.gear st.success 1
scoreboard players set $m.gear st.activate 0
schedule clear cw:geardrop