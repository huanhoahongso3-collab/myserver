tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $pl.smai st.success 1
scoreboard players set $pl.smai st.activate 0
schedule clear cw:piglin/swapper