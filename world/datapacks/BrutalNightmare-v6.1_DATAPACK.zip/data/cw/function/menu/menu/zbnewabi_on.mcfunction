tellraw @a "[MENU] Menu Activated"
scoreboard players set $zb.newabi st.success 1
scoreboard players set $zb.newabi st.activate 1
function cw:zombie/ability
function cw:husk/ability