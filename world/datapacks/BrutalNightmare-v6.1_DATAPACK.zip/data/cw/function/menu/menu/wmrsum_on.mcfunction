tellraw @a "[MENU] Menu Activated"
scoreboard players set $wm.rsum st.success 1
scoreboard players set $wm.rsum st.activate 1
function cw:watermob/move
function cw:watermob/random_popup
function cw:watermob/summon