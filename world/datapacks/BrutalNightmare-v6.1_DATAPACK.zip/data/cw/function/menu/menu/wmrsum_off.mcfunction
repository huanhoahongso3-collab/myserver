tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $wm.rsum st.success 1
scoreboard players set $wm.rsum st.activate 0
schedule clear cw:watermob/move
schedule clear cw:watermob/random_popup
schedule clear cw:watermob/summon