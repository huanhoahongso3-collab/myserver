tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $zb.allbreaker st.success 1
scoreboard players set $zb.allbreaker st.activate 0
function cw:menu/zbnewabi_on