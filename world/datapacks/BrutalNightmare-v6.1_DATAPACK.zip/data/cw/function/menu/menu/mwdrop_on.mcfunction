tellraw @a "[MENU] Menu Activated"
scoreboard players set $mw.drop st.success 1
scoreboard players set $mw.drop st.activate 1
function cw:mwitch/drop