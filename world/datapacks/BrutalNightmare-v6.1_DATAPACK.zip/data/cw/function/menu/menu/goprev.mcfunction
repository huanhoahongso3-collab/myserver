execute if score $cw.fs cw.menu.page matches 2..5 run scoreboard players remove $cw.fs cw.menu.page 1
function cw:menu/main