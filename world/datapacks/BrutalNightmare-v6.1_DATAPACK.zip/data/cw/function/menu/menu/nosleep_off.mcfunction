tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $nosleep st.success 1
scoreboard players set $nosleep st.activate 0
function cw:nosleep_disable