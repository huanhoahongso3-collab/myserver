tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $mw.freeze st.success 1
scoreboard players set $mw.freeze st.activate 0
schedule clear cw:mwitch/freeze
schedule clear cw:mwitch/curse/tick