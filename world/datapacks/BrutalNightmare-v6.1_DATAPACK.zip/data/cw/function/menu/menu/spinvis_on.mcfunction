tellraw @a "[MENU] Menu Activated"
scoreboard players set $sp.invis st.success 1
scoreboard players set $sp.invis st.activate 1
function cw:spider/invisible