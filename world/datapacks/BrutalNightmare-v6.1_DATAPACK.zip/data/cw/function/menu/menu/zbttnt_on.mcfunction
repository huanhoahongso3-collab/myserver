tellraw @a "[MENU] Menu Activated"
scoreboard players set $zb.ttnt st.success 1
scoreboard players set $zb.ttnt st.activate 1
function cw:zombie/zombie_throw_tnt
function cw:husk/husk_throw_tnt