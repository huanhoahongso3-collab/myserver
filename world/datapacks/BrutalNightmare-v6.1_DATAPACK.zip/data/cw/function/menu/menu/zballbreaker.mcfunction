scoreboard players set $zb.allbreaker st.success 0
execute as @s if score $zb.allbreaker st.success matches 0 if score $zb.allbreaker st.activate matches 1 run function cw:menu/zballbreaker_off
execute as @s if score $zb.allbreaker st.success matches 0 unless score $zb.allbreaker st.activate matches 1 run function cw:menu/zballbreaker_on
scoreboard players set $zb.allbreaker st.success 0
function cw:menu/main