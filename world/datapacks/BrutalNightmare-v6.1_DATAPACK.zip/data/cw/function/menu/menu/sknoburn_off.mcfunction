tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $sk.noburn st.success 1
scoreboard players set $sk.noburn st.activate 0
schedule clear cw:skeleton/ssmob