scoreboard players set $mw.enable st.success 0
execute as @s if score $mw.enable st.success matches 0 if score $mw.enable st.activate matches 1 run function cw:menu/mwenable_off
execute as @s if score $mw.enable st.success matches 0 unless score $mw.enable st.activate matches 1 run function cw:menu/mwenable_on
scoreboard players set $mw.enable st.success 0
function cw:menu/main