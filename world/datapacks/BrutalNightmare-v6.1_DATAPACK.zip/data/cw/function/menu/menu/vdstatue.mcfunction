scoreboard players set $vd.statue st.success 0
execute as @s if score $vd.statue st.success matches 0 if score $vd.statue st.activate matches 1 run function cw:menu/vdstatue_off
execute as @s if score $vd.statue st.success matches 0 unless score $vd.statue st.activate matches 1 run function cw:menu/vdstatue_on
scoreboard players set $vd.statue st.success 0
function cw:menu/main