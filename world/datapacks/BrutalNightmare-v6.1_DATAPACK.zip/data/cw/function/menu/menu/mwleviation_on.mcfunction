tellraw @a "[MENU] Menu Activated"
scoreboard players set $mw.leviation st.success 1
scoreboard players set $mw.leviation st.activate 1
function cw:mwitch/leviation