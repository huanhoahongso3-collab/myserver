scoreboard players set $sp.shtweb st.success 0
execute as @s if score $sp.shtweb st.success matches 0 if score $sp.shtweb st.activate matches 1 run function cw:menu/spshtweb_off
execute as @s if score $sp.shtweb st.success matches 0 unless score $sp.shtweb st.activate matches 1 run function cw:menu/spshtweb_on
scoreboard players set $sp.shtweb st.success 0
function cw:menu/main