tellraw @a "[MENU] Menu Activated"
scoreboard players set $ptom.invis st.success 1
scoreboard players set $ptom.invis st.activate 1
function cw:phantom/invisible