scoreboard players set $mw.leviation st.success 0
execute as @s if score $mw.leviation st.success matches 0 if score $mw.leviation st.activate matches 1 run function cw:menu/mwleviation_off
execute as @s if score $mw.leviation st.success matches 0 unless score $mw.leviation st.activate matches 1 run function cw:menu/mwleviation_on
scoreboard players set $mw.leviation st.success 0
function cw:menu/main