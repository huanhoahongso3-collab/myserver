scoreboard players set $zb.smoften st.success 0
execute as @s if score $zb.smoften st.success matches 0 if score $zb.smoften st.activate matches 1 run function cw:menu/zbsmoften_off
execute as @s if score $zb.smoften st.success matches 0 unless score $zb.smoften st.activate matches 1 run function cw:menu/zbsmoften_on
scoreboard players set $zb.smoften st.success 0
function cw:menu/main