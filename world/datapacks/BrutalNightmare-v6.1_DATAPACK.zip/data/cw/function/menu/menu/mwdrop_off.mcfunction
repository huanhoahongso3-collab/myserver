tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $mw.drop st.success 1
scoreboard players set $mw.drop st.activate 0
schedule clear cw:mwitch/drop