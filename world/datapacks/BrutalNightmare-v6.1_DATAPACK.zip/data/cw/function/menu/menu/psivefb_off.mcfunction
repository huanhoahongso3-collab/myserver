tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $psive.fb st.success 1
scoreboard players set $psive.fb st.activate 0