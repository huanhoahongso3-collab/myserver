tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $mw.leviation st.success 1
scoreboard players set $mw.leviation st.activate 0
schedule clear cw:mwitch/leviation