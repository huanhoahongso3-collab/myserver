scoreboard players set $zb.dbs st.success 0
execute as @s if score $zb.dbs st.success matches 0 if score $zb.dbs st.activate matches 1 run function cw:menu/zbdbs_off
execute as @s if score $zb.dbs st.success matches 0 unless score $zb.dbs st.activate matches 1 run function cw:menu/zbdbs_on
scoreboard players set $zb.dbs st.success 0
function cw:menu/main