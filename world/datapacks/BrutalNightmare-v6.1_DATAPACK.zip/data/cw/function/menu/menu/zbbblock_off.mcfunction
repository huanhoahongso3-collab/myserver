tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $zb.bblock st.success 1
scoreboard players set $zb.bblock st.activate 0
schedule clear cw:zombie/breakblock
schedule clear cw:husk/breakblock
execute unless score $zb.pblock st.activate matches 1 run schedule clear cw:zombie/placeblock_under
execute unless score $zb.pblock st.activate matches 1 run schedule clear cw:husk/placeblock_under