tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $ws.caskill st.success 1
scoreboard players set $ws.caskill st.activate 0
schedule clear cw:witherskeleton/wskeleton