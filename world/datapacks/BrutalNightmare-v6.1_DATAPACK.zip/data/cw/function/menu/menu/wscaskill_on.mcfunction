tellraw @a "[MENU] Menu Activated"
scoreboard players set $ws.caskill st.success 1
scoreboard players set $ws.caskill st.activate 1
function cw:witherskeleton/wskeleton