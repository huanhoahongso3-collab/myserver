scoreboard players set $mw.spread st.success 0
execute as @s if score $mw.spread st.success matches 0 if score $mw.spread st.activate matches 1 run function cw:menu/mwspread_off
execute as @s if score $mw.spread st.success matches 0 unless score $mw.spread st.activate matches 1 run function cw:menu/mwspread_on
scoreboard players set $mw.spread st.success 0
function cw:menu/main