tellraw @a "[MENU] Menu Activated"
scoreboard players set $mw.enable st.success 1
scoreboard players set $mw.enable st.activate 1
function cw:mwitch/mwitch