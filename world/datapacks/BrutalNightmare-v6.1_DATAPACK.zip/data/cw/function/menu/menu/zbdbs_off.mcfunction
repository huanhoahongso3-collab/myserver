tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $zb.dbs st.success 1
scoreboard players set $zb.dbs st.activate 0
schedule clear cw:zombie/dbs