tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $sk.caskill st.success 1
scoreboard players set $sk.caskill st.activate 0
schedule clear cw:skeleton/skeleton