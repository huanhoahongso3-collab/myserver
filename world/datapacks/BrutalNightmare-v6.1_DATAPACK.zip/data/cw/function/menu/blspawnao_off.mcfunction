tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $bl.spawnao st.success 1
scoreboard players set $bl.spawnao st.activate 0
schedule clear cw:blaze/spawn