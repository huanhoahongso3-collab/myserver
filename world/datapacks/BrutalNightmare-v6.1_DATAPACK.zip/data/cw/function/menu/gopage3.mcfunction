scoreboard players set $cw.fs cw.menu.page 3
function cw:menu/main