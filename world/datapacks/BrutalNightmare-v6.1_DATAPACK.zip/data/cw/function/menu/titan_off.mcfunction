tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $titan st.success 1
scoreboard players set $titan st.activate 0
schedule clear cw:hardattrb/titan