tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $hardattrb st.success 1
scoreboard players set $hardattrb st.activate 0
schedule clear cw:hardattrb/hardattrb