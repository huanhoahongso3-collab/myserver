tellraw @a "[MENU] Menu Activated"
scoreboard players set $em.caskill st.success 1
scoreboard players set $em.caskill st.activate 1
function cw:em/telem_touch