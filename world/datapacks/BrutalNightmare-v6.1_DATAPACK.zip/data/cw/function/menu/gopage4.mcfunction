scoreboard players set $cw.fs cw.menu.page 4
function cw:menu/main