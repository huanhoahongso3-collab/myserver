tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $em.caskill st.success 1
scoreboard players set $em.caskill st.activate 0
schedule clear cw:em/telem_touch