scoreboard players set $em.invis st.success 0
execute as @s if score $em.invis st.success matches 0 if score $em.invis st.activate matches 1 run function cw:menu/eminvis_off
execute as @s if score $em.invis st.success matches 0 unless score $em.invis st.activate matches 1 run function cw:menu/eminvis_on
scoreboard players set $em.invis st.success 0
function cw:menu/main