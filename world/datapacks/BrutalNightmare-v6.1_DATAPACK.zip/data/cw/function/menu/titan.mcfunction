scoreboard players set $titan st.success 0
execute as @s if score $titan st.success matches 0 if score $titan st.activate matches 1 run function cw:menu/titan_off
execute as @s if score $titan st.success matches 0 unless score $titan st.activate matches 1 run function cw:menu/titan_on
scoreboard players set $titan st.success 0
function cw:menu/main