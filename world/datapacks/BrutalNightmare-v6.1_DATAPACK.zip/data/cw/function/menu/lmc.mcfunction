scoreboard players set $l.mc st.success 0
execute as @s if score $l.mc st.success matches 0 if score $l.mc st.activate matches 1 run function cw:menu/lmc_off
execute as @s if score $l.mc st.success matches 0 unless score $l.mc st.activate matches 1 run function cw:menu/lmc_on
scoreboard players set $l.mc st.success 0
function cw:menu/main