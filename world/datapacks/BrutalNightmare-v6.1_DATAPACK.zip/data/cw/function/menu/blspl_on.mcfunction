tellraw @a "[MENU] Menu Activated"
scoreboard players set $bl.spl st.success 1
scoreboard players set $bl.spl st.activate 1