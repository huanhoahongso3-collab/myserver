scoreboard players set $cr.sap st.success 0
execute as @s if score $cr.sap st.success matches 0 if score $cr.sap st.activate matches 1 run function cw:menu/crsap_off
execute as @s if score $cr.sap st.success matches 0 unless score $cr.sap st.activate matches 1 run function cw:menu/crsap_on
scoreboard players set $cr.sap st.success 0
function cw:menu/main