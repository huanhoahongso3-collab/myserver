tellraw @a "[MENU] Menu Activated"
scoreboard players set $titan st.success 1
scoreboard players set $titan st.activate 1
function cw:hardattrb/titan