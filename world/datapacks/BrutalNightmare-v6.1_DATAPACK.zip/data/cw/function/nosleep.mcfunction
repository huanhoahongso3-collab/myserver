scoreboard players set $4JWmG4jCpP HYKNM 0
execute if score $4JWmG4jCpP HYKNM matches 0 run function cw:nxf/_ignored_nosleep_l4r9y4
execute if score $4JWmG4jCpP HYKNM matches 0 run function cw:nxf/_ignored_nosleep_sozri6y
execute if score $4JWmG4jCpP HYKNM matches 0 run function cw:nxf/_ignored_nosleep_zz28
scoreboard players set $4JWmG4jCpP HYKNM 0