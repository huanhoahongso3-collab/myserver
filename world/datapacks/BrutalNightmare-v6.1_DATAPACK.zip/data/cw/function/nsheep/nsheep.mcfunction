execute if score $psive.fb st.activate matches 1 run function cw:nxf/nsheep_eydko6n6f3
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/nsheep_nq2sk944