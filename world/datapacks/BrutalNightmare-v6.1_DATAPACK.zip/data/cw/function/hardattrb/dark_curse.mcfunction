schedule function cw:hardattrb/dark_curse 1s
execute as @a[gamemode=survival] at @s run function cw:nxf/dark_curse_78znufh