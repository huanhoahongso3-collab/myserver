schedule function cw:ghasts/gh_gatling 4s
execute as @a at @s as @e[type=ghast,distance=..80,tag=!gh.rn] at @s if predicate cw:r45 run function cw:nxf/gh_gatling_fb7id66e