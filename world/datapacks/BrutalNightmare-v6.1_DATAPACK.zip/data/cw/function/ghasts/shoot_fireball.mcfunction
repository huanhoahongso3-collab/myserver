summon fireball ~ ~ ~ {Tags:["cw.fb"]}
execute as @e[type=minecraft:fireball,tag=cw.fb] at @s run tp @s ~ ~ ~ facing entity @p
execute as @e[type=minecraft:fireball,tag=cw.fb] at @s run function cw:nxf/shoot_fireball_7lkcxjh45