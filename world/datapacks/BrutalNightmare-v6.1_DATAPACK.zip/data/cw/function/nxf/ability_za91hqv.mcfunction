execute if score $zb.allbreaker st.activate matches 1 run function cw:nxf/ability_nxmcj8n796
execute unless score $zb.allbreaker st.activate matches 1 run function cw:nxf/ability_dppk
scoreboard players set $RAwa60E HYKNM 0
execute if score $RAwa60E HYKNM matches 0 as @s[scores={sb.abil=0}] run function cw:nxf/ability_t37w47
execute if score $RAwa60E HYKNM matches 0 as @s[scores={sb.abil=1}] run function cw:nxf/ability_s1hl
execute if score $RAwa60E HYKNM matches 0 as @s[scores={sb.abil=2}] run function cw:nxf/ability_l53j3xtlr7r
execute if score $RAwa60E HYKNM matches 0 as @s[scores={sb.abil=3}] run function cw:nxf/ability_z6ei0i3lkg
execute if score $RAwa60E HYKNM matches 0 as @s[scores={sb.abil=4}] run function cw:nxf/ability_niadosip
scoreboard players set $RAwa60E HYKNM 0