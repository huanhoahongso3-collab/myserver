tag @s add cw.onlyme
tag @s add cw.axe_tl
scoreboard players set $0IgW HYKNM 0
execute if score $0IgW HYKNM matches 0 run function cw:nxf/_ignored_ability_ndllr1q
execute if score $0IgW HYKNM matches 0 run function cw:nxf/_ignored_ability_kei05rytyw9
scoreboard players set $0IgW HYKNM 0
tag @s add specabi
scoreboard players set $RAwa60E HYKNM 1