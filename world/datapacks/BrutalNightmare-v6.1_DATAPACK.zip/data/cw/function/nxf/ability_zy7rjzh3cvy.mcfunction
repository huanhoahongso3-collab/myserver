scoreboard players set $jLdq HYKNM 0
execute if score $jLdq HYKNM matches 0 if entity @p[distance=5..7] run function cw:nxf/ability_6rj2
execute if score $jLdq HYKNM matches 0 if entity @p[distance=8..18] run function cw:nxf/ability_cdk2o4dn
scoreboard players set $jLdq HYKNM 0