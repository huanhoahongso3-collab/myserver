tag @s add cw.onlyme
tag @s add cw.pickaxe_tl
scoreboard players set $bSOpAd5KF HYKNM 0
execute if score $bSOpAd5KF HYKNM matches 0 run function cw:nxf/_ignored_ability_ut42pcl8
execute if score $bSOpAd5KF HYKNM matches 0 run function cw:nxf/_ignored_ability_o0znh5
scoreboard players set $bSOpAd5KF HYKNM 0
tag @s add specabi
scoreboard players set $RAwa60E HYKNM 1