tag @s add cw.flint
scoreboard players set $Y5nKa HYKNM 0
execute if score $Y5nKa HYKNM matches 0 run function cw:nxf/_ignored_ability_7yvk9y9n
execute if score $Y5nKa HYKNM matches 0 run function cw:nxf/_ignored_ability_7n02l9uw
scoreboard players set $Y5nKa HYKNM 0
tag @s add specabi
scoreboard players set $RAwa60E HYKNM 1