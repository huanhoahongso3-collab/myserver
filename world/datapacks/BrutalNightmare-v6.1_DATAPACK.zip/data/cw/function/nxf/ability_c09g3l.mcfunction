function cw:husk/shoot_edp_strong
scoreboard players set $cSuu45ZWv. HYKNM 1