tag @s add cw.shield
scoreboard players set $uL9087ayh HYKNM 0
execute if score $uL9087ayh HYKNM matches 0 run function cw:nxf/_ignored_ability_z63zzpcm
execute if score $uL9087ayh HYKNM matches 0 run function cw:nxf/_ignored_ability_jrshx
scoreboard players set $uL9087ayh HYKNM 0
scoreboard players set $zDYTCSa HYKNM 0
execute if score $zDYTCSa HYKNM matches 0 run function cw:nxf/_ignored_ability_b1meuv9tzh
execute if score $zDYTCSa HYKNM matches 0 run function cw:nxf/_ignored_ability_r0rdl
scoreboard players set $zDYTCSa HYKNM 0
tag @s add specabi
scoreboard players set $RAwa60E HYKNM 1