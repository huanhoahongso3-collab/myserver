function cw:zombie/shoot_edp
scoreboard players set $jLdq HYKNM 1