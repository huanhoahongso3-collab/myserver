function cw:husk/shoot_edp
scoreboard players set $cSuu45ZWv. HYKNM 1