tag @s add cw.enderp
scoreboard players set $NL9EZXxie HYKNM 0
execute if score $NL9EZXxie HYKNM matches 0 run function cw:nxf/_ignored_ability_xvr9pgvr
execute if score $NL9EZXxie HYKNM matches 0 run function cw:nxf/_ignored_ability_blrldertcnx
scoreboard players set $NL9EZXxie HYKNM 0
tag @s add specabi
scoreboard players set $AiZi4ipM94 HYKNM 1