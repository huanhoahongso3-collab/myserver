tag @s add cw.shield
scoreboard players set $X.U0Na HYKNM 0
execute if score $X.U0Na HYKNM matches 0 run function cw:nxf/_ignored_ability_zrcpg0g5myj
execute if score $X.U0Na HYKNM matches 0 run function cw:nxf/_ignored_ability_uv0tae1jx
scoreboard players set $X.U0Na HYKNM 0
scoreboard players set $kD2czjgwv HYKNM 0
execute if score $kD2czjgwv HYKNM matches 0 run function cw:nxf/_ignored_ability_l5hyju1hjr
execute if score $kD2czjgwv HYKNM matches 0 run function cw:nxf/_ignored_ability_aks8pd
scoreboard players set $kD2czjgwv HYKNM 0
tag @s add specabi
scoreboard players set $AiZi4ipM94 HYKNM 1