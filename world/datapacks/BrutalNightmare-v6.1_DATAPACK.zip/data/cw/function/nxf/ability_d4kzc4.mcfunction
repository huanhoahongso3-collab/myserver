execute if score $zb.allbreaker st.activate matches 1 run function cw:nxf/ability_uy28
execute unless score $zb.allbreaker st.activate matches 1 run function cw:nxf/ability_mauh14
scoreboard players set $AiZi4ipM94 HYKNM 0
execute if score $AiZi4ipM94 HYKNM matches 0 as @s[scores={sb.abil=0}] run function cw:nxf/ability_2n5i4i07r5
execute if score $AiZi4ipM94 HYKNM matches 0 as @s[scores={sb.abil=1}] run function cw:nxf/ability_oki9
execute if score $AiZi4ipM94 HYKNM matches 0 as @s[scores={sb.abil=2}] run function cw:nxf/ability_yu6il1cq
execute if score $AiZi4ipM94 HYKNM matches 0 as @s[scores={sb.abil=3}] run function cw:nxf/ability_dmgxdk
execute if score $AiZi4ipM94 HYKNM matches 0 as @s[scores={sb.abil=4}] run function cw:nxf/ability_0t3s2dxd4vz
scoreboard players set $AiZi4ipM94 HYKNM 0