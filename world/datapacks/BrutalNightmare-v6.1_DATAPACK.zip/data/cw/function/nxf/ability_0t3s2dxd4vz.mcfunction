tag @s add cw.onlyme
tag @s add cw.axe_tl
scoreboard players set $I5ZspRcUb HYKNM 0
execute if score $I5ZspRcUb HYKNM matches 0 run function cw:nxf/_ignored_ability_dyw8epex8
execute if score $I5ZspRcUb HYKNM matches 0 run function cw:nxf/_ignored_ability_xg70fmwz
scoreboard players set $I5ZspRcUb HYKNM 0
tag @s add specabi
scoreboard players set $AiZi4ipM94 HYKNM 1