tag @s add cw.cage.tg
function cw:extend/_ignored_line_particle