tag @s add cw.onlyme
tag @s add cw.pickaxe_tl
scoreboard players set $MeJg1uNh HYKNM 0
execute if score $MeJg1uNh HYKNM matches 0 run function cw:nxf/_ignored_ability_hezg
execute if score $MeJg1uNh HYKNM matches 0 run function cw:nxf/_ignored_ability_ld5nsf9n
scoreboard players set $MeJg1uNh HYKNM 0
tag @s add specabi
scoreboard players set $AiZi4ipM94 HYKNM 1