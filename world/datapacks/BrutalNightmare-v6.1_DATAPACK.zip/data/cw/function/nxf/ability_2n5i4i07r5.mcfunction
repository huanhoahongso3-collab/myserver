tag @s add cw.flint
scoreboard players set $XDp8oR HYKNM 0
execute if score $XDp8oR HYKNM matches 0 run function cw:nxf/_ignored_ability_gkla75
execute if score $XDp8oR HYKNM matches 0 run function cw:nxf/_ignored_ability_ynu0c3k
scoreboard players set $XDp8oR HYKNM 0
tag @s add specabi
scoreboard players set $AiZi4ipM94 HYKNM 1