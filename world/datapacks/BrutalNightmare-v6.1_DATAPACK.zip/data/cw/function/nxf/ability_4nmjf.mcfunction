scoreboard players set $cSuu45ZWv. HYKNM 0
execute if score $cSuu45ZWv. HYKNM matches 0 if entity @p[distance=5..7] run function cw:nxf/ability_fhnlq2x
execute if score $cSuu45ZWv. HYKNM matches 0 if entity @p[distance=8..18] run function cw:nxf/ability_c09g3l
scoreboard players set $cSuu45ZWv. HYKNM 0