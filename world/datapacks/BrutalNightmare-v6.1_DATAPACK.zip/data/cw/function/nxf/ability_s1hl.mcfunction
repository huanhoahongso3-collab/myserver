tag @s add cw.enderp
scoreboard players set $RwGseKjH HYKNM 0
execute if score $RwGseKjH HYKNM matches 0 run function cw:nxf/_ignored_ability_ase8av0is87
execute if score $RwGseKjH HYKNM matches 0 run function cw:nxf/_ignored_ability_7782
scoreboard players set $RwGseKjH HYKNM 0
tag @s add specabi
scoreboard players set $RAwa60E HYKNM 1