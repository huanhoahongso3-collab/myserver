function cw:zombie/shoot_edp_strong
scoreboard players set $jLdq HYKNM 1