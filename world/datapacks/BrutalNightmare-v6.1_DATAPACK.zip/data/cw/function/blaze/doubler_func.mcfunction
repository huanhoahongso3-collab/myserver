execute if score $bl.spl st.activate matches 1 run summon lightning_bolt ~ ~ ~
summon blaze ~ ~ ~ {Tags:["doubler"]}
summon blaze ~ ~ ~ {Tags:["doubler"]}
function fokus:disappear