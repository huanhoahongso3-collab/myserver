schedule function cw:blaze/doubler 1s
scoreboard players set $OP6GN HYKNM 0
execute if score $OP6GN HYKNM matches 0 run function cw:nxf/_ignored_doubler_jopnk5vdxa
execute if score $OP6GN HYKNM matches 0 run function cw:nxf/_ignored_doubler_d8ycry
scoreboard players set $OP6GN HYKNM 0
execute as @a at @s run function cw:nxf/doubler_qda5gt3djug