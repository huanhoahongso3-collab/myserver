schedule function cw:blaze/spawn 40s
execute as @r[limit=7] at @s if predicate cw:r10 run function cw:nxf/spawn_6e4lyj