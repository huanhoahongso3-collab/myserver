schedule function cw:blaze/use_curse 60s
execute at @a[gamemode=survival] as @e[type=blaze,distance=..30,tag=!exc,limit=1,sort=nearest] at @s if predicate cw:r20 run function cw:nxf/use_curse_efaw2k