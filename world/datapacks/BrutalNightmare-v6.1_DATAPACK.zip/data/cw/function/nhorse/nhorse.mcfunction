execute if score $psive.fb st.activate matches 1 run function cw:nxf/nhorse_y3yk7v4qbn
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/nhorse_3lzr