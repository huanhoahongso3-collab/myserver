execute if score $psive.fb st.activate matches 1 run function cw:nxf/npig_9blh9a9
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/npig_y3sodf3oiv