execute if score $psive.fb st.activate matches 1 run function cw:nxf/nchicken_7gfyxlomn9
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/nchicken_stlgn