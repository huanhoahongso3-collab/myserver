schedule function cw:husk/placeblock_under 1s
execute if score $zb.allbreaker st.activate matches 1 run function cw:nxf/placeblock_under_5rd5otb77sj
execute unless score $zb.allbreaker st.activate matches 1 run function cw:nxf/placeblock_under_znoqen738