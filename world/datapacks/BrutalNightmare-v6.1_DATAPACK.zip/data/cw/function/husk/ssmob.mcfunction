schedule function cw:zombie/ssmob 1t
execute as @e[type=minecraft:zombie,tag=!zb.wss] run function cw:nxf/ssmob_ty4ui7