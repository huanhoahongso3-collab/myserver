schedule function cw:husk/dbs 45s
execute as @e[tag=dbs,type=marker,sort=random,limit=30] at @s if block ~ ~ ~ dirt run function cw:nxf/dbs_6ev2sj