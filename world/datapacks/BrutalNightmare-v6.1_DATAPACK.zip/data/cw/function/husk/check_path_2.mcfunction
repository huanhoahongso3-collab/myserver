scoreboard players set @s gl.pathAv 0
execute as @s at @s[scores={gl.pathAv=0}] positioned ~ ~-1 ~ unless block ^ ^ ^1 #cw:transparent run scoreboard players set @s gl.pathAv 1