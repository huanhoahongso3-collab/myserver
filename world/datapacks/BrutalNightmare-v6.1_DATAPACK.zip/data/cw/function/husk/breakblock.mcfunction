schedule function cw:husk/breakblock 5s
execute if score $zb.allbreaker st.activate matches 1 run function cw:nxf/breakblock_jda08dr9
execute unless score $zb.allbreaker st.activate matches 1 run function cw:nxf/breakblock_6vvl76ops