scoreboard players set $cw.wc cw.fl 0
execute if score $fokus.rn islib matches 1 run function cw:nxf/load_welcome_obpdo4cl53l
execute if score $reactify.rn islib matches 1 run function cw:nxf/load_welcome_jwqu
execute if score $cw.wc cw.fl matches 1 unless score $bn.wm st.activate matches 0 run tellraw @a [{"text":"[BrutalNightmare] Open settings with /function cw:menu/main.","bold":true,"color":"green"}]
execute unless score $cw.wc cw.fl matches 1 run schedule function cw:load_welcome 5s