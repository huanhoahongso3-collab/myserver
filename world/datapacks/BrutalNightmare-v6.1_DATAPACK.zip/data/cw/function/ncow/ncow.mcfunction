execute if score $psive.fb st.activate matches 1 run function cw:nxf/ncow_j9doc
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/ncow_43tn