tp @s ~ ~ ~ facing entity @p
execute as @e[type=vex,tag=cw.sword_qi] at @s run function cw:nxf/sw_hitbox_sword_qi_iwo3ajcarpy