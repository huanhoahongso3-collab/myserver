schedule function cw:abilities/cage_loop 5t
execute as @e[type=armor_stand,tag=cw.cage] at @s run function cw:nxf/cage_loop_elekatdnh10