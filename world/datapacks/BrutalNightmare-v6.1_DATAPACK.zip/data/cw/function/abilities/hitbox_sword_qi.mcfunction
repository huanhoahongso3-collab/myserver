tp @s ~ ~ ~ facing entity @p
execute as @e[type=vex,tag=cw.sword_qi] at @s run function cw:nxf/hitbox_sword_qi_nc8llz26j