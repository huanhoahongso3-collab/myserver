effect clear @s minecraft:bad_omen
effect give @s minecraft:bad_omen 6000 4 false