advancement revoke @s only nova_structures:adventure/conquer_barrack_captain_repeat

effect clear @s minecraft:bad_omen
effect give @s minecraft:bad_omen 6000 4 false